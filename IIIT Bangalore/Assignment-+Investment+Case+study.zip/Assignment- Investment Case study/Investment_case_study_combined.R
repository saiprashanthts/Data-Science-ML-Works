#loading package
library("stringr")
library("tidyr")
library("dplyr")
library("plyr")
library("sqldf")


# loading data
companies <- read.delim("companies.txt", stringsAsFactors = F)
rounds2 <- read.csv("rounds2.csv", stringsAsFactors = F)
mapping <- read.csv("mapping.csv", stringsAsFactors = F)


#data cleanup for companies database

companies_clean <- companies
companies_clean$permalink <- str_to_lower(companies_clean$permalink, locale = "en")
companies_clean$name <- str_replace_all(companies_clean$name, "[-)(*&^%$#@!:;'<,>./?]"," ")
companies_clean$name <- str_remove(companies_clean$name, pattern = "^ ?")


# data cleanup for round2 database
round2_clean <- rounds2
round2_clean$company_permalink <- str_to_lower(round2_clean$company_permalink, locale = "en")

#distinct companies in round2 dataset
unique_company_round2 <- distinct(round2_clean, company_permalink)
# Ans 66368

#distinct companies in companies dataset
distinct_company_companies <- distinct(companies_clean, permalink)
# Ans 66368

#In the companies data frame, which column can be used as the unique key for each company?
#Write the name of the column.
#Ans:permalink

#Are there any companies in the rounds2 file which are not present in companies?
#Answer yes or no: Y/N
#Ans:N

master_frame <- merge(round2_clean, companies_clean, by.x = 'company_permalink', by.y = 'permalink')


#average investment in each group
master_frame$funding_round_type <- as.factor(master_frame$funding_round_type)

Avg_funding_all_type<- aggregate(raised_amount_usd ~ funding_round_type, master_frame, FUN = mean)


# Average funding amount of venture type
#Ans : 11748949.1 (~11.7million)

# Average funding amount of angel type
#Ans: 958694.5 (~1million)

# Average funding amount of seed type
# Ans: 719818.0 (~0.7million)

# Average funding amount of private equity type
# Ans:73308593.0 (~73million)

# Considering that Spark Funds wants to invest between 5 to 15 million USD per investment round, which investment type is the most suitable for it?
# Ans: Venture

#checkpoint 3
#Subsetting venture from master_frame

master_frame<- subset(master_frame, master_frame$funding_round_type == "venture")

sum_over_country <- aggregate(raised_amount_usd ~ country_code, master_frame, sum)

#not considering country with no name

sum_over_country_clean <- sum_over_country[-1,]

# top 9 countries based on overall investment
sum_over_country_arranged <- arrange(sum_over_country_clean, desc(raised_amount_usd))
top9<- sum_over_country_arranged[c(1:9),]

# Top English-speaking country
#Ans:USA

# Second English-speaking country
#Ans: GBR (United Kingdom)

# Third English-speaking country
#Ans: IND

#checkpoint 4,5
# mapping dataset wide to long

mapping_long <- gather(mapping, main_sectors, my_val, Automotive...Sports: Social..Finance..Analytics..Advertising)
mapping_long <- mapping_long[!(mapping_long$my_val == 0), ]
mapping_long <- mapping_long[, -3]

# cleaning mapping_long dataset

mapping_long$category_list <- str_to_lower(mapping_long$category_list, locale = "en")
mapping_long$category_list <- str_replace_all(mapping_long$category_list, pattern = "0", replacement = "na")
mapping_long$category_list <- str_replace_all(mapping_long$category_list, pattern = "2.na", replacement = "2.0")



# getting primary sector from master_frame

primary_sector<- str_split_fixed(master_frame$category_list, pattern = "[|]", 2)
primary_sector<- primary_sector[, -2]

#adding primary_sector in master_frame
master_frame$primary_sector <- primary_sector
master_frame$primary_sector <- str_to_lower(master_frame$primary_sector, locale = "en")
master_frame <- merge(master_frame, mapping_long, by.x = "primary_sector", by.y = "category_list")

#removing blank category
master_frame <- filter(master_frame, main_sectors != "Blanks")


# subsetting based on top 3 english speaking country
  
USA <- subset(master_frame, country_code == "USA" & raised_amount_usd >= 5000000 & raised_amount_usd <= 15000000)
GBR <- subset(master_frame, country_code == "GBR" & raised_amount_usd >= 5000000 & raised_amount_usd <= 15000000)
IND <- subset(master_frame, country_code == "IND" & raised_amount_usd >= 5000000 & raised_amount_usd <= 15000000)


# To Find Total number and amount of investment in each countries

sqldf('select count(*) as total_number_of_investments from USA ')

sqldf('select count(*) as total_number_of_investments from GBR ')

sqldf('select count(*) as total_number_of_investments from IND ')

sqldf('select sum(raised_amount_usd) from USA ')

sqldf('select sum(raised_amount_usd) from GBR ')

sqldf('select sum(raised_amount_usd) from IND ')



# For Obtaining Count and Sum of each sector as columns of USA(D1), GBR(D2),IND(D3) 
D1CountSumdf <- sqldf('select count(*) as total_number_of_investments,sum(raised_amount_usd) as sum_of_investments,main_sectors from USA group by main_sectors order by 1 desc')
D2CountSumdf <- sqldf('select count(*) as total_number_of_investments,sum(raised_amount_usd) as sum_of_investments,main_sectors from GBR group by main_sectors order by 1 desc')
D3CountSumdf <- sqldf('select count(*) as total_number_of_investments,sum(raised_amount_usd) as sum_of_investments,main_sectors from IND group by main_sectors order by 1 desc')

D1Countf1 <- spread(D1CountSumdf[,-2],main_sectors,total_number_of_investments)
D1sumdf1 <- spread(D1CountSumdf[,-1],main_sectors,sum_of_investments)
USA_D1 <- cbind(D1Countf1,D1sumdf1)
names(USA_D1) <- c('count_Automotive...Sports','count Cleantech...Semiconductors','count Entertainment','count Health','count Manufacturing','count News..Search.and.Messaging','count Others','count Social..Finance..Analytics..Advertising'
                ,'sum_Automotive...Sports','sum Cleantech...Semiconductors','sum Entertainment','sum Health','sum Manufacturing','sum News..Search.and.Messaging','sum Others','sum Social..Finance..Analytics..Advertising')


USA[,c('count_Automotive...Sports','count Cleantech...Semiconductors','count Entertainment','count Health','count Manufacturing','count News..Search.and.Messaging','count Others','count Social..Finance..Analytics..Advertising'
      ,'sum_Automotive...Sports','sum Cleantech...Semiconductors',
      'sum Entertainment','sum Health','sum Manufacturing','sum News..Search.and.Messaging','sum Others','sum Social..Finance..Analytics..Advertising')
   ] <- NA

USA[1,c('count_Automotive...Sports','count Cleantech...Semiconductors','count Entertainment','count Health','count Manufacturing','count News..Search.and.Messaging','count Others','count Social..Finance..Analytics..Advertising'
       ,'sum_Automotive...Sports','sum Cleantech...Semiconductors',
       'sum Entertainment','sum Health','sum Manufacturing','sum News..Search.and.Messaging','sum Others','sum Social..Finance..Analytics..Advertising')
   ] <- USA_D1[1,]


D2Countf1 <- spread(D2CountSumdf[,-2],main_sectors,total_number_of_investments)
D2sumdf1 <- spread(D2CountSumdf[,-1],main_sectors,sum_of_investments)
GBR_D2 <- cbind(D2Countf1,D2sumdf1)
names(GBR_D2) <- c('count_Automotive...Sports','count Cleantech...Semiconductors','count Entertainment','count Health','count Manufacturing','count News..Search.and.Messaging','count Others','count Social..Finance..Analytics..Advertising'
                ,'sum_Automotive...Sports','sum Cleantech...Semiconductors','sum Entertainment','sum Health','sum Manufacturing','sum News..Search.and.Messaging','sum Others','sum Social..Finance..Analytics..Advertising')

GBR[,c('count_Automotive...Sports','count Cleantech...Semiconductors','count Entertainment','count Health','count Manufacturing','count News..Search.and.Messaging','count Others','count Social..Finance..Analytics..Advertising'
      ,'sum_Automotive...Sports','sum Cleantech...Semiconductors',
      'sum Entertainment','sum Health','sum Manufacturing','sum News..Search.and.Messaging','sum Others','sum Social..Finance..Analytics..Advertising')
   ] <- NA

GBR[1,c('count_Automotive...Sports','count Cleantech...Semiconductors','count Entertainment','count Health','count Manufacturing','count News..Search.and.Messaging','count Others','count Social..Finance..Analytics..Advertising'
       ,'sum_Automotive...Sports','sum Cleantech...Semiconductors',
       'sum Entertainment','sum Health','sum Manufacturing','sum News..Search.and.Messaging','sum Others','sum Social..Finance..Analytics..Advertising')
   ] <- GBR_D2[1,]



D3Countf1 <- spread(D3CountSumdf[,-2],main_sectors,total_number_of_investments)
D3sumdf1 <- spread(D3CountSumdf[,-1],main_sectors,sum_of_investments)
IND_D3 <-cbind(D3Countf1,D3sumdf1)
names(IND_D3) <- c('count_Automotive...Sports','count Cleantech...Semiconductors','count Entertainment','count Health','count Manufacturing','count News..Search.and.Messaging','count Others','count Social..Finance..Analytics..Advertising'
                ,'sum_Automotive...Sports','sum Cleantech...Semiconductors','sum Entertainment','sum Health','sum Manufacturing','sum News..Search.and.Messaging','sum Others','sum Social..Finance..Analytics..Advertising')

IND[,c('count_Automotive...Sports','count Cleantech...Semiconductors','count Entertainment','count Health','count Manufacturing','count News..Search.and.Messaging','count Others','count Social..Finance..Analytics..Advertising'
      ,'sum_Automotive...Sports','sum Cleantech...Semiconductors',
      'sum Entertainment','sum Health','sum Manufacturing','sum News..Search.and.Messaging','sum Others','sum Social..Finance..Analytics..Advertising')
   ] <- NA

IND[1,c('count_Automotive...Sports','count Cleantech...Semiconductors','count Entertainment','count Health','count Manufacturing','count News..Search.and.Messaging','count Others','count Social..Finance..Analytics..Advertising'
       ,'sum_Automotive...Sports','sum Cleantech...Semiconductors',
       'sum Entertainment','sum Health','sum Manufacturing','sum News..Search.and.Messaging','sum Others','sum Social..Finance..Analytics..Advertising')
   ] <- IND_D3[1,]

# Aggregating investment received in various rounds by company to find the company who received maximum investment in Top sector i.e. "Others"

USA_max_invest_com_sector_other<- sqldf('select name, sum(raised_amount_usd) as total_investment from USA where main_sectors = "Others" group by company_permalink order by total_investment desc')
GBR_max_invest_com_sector_other<- sqldf('select name, sum(raised_amount_usd) as total_investment from GBR where main_sectors = "Others" group by company_permalink order by total_investment desc')
IND_max_invest_com_sector_other<- sqldf('select name, sum(raised_amount_usd) as total_investment from IND where main_sectors = "Others" group by company_permalink order by total_investment desc')

# Aggregating investment received in various rounds by company to find the company who received maximum investment in second top sector i.e. "Social..Finance..Analytics..Advertising"

USA_max_invest_com_sector_Social<- sqldf('select name, sum(raised_amount_usd) as total_investment from USA where main_sectors = "Social..Finance..Analytics..Advertising" group by company_permalink order by total_investment desc')
GBR_max_invest_com_sector_Social<- sqldf('select name, sum(raised_amount_usd) as total_investment from GBR where main_sectors = "Social..Finance..Analytics..Advertising" group by company_permalink order by total_investment desc')
IND_max_invest_com_sector_Social<- sqldf('select name, sum(raised_amount_usd) as total_investment from IND where main_sectors = "Social..Finance..Analytics..Advertising" group by company_permalink order by total_investment desc')

# Creating D1 , D2 and D3 which is same as USA,GBR,IND respectively
D1 <- USA
D2 <- GBR
D3<- IND