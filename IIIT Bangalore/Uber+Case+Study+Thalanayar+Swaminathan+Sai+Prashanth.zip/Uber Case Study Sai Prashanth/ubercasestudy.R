# Calling the required Packages
library(lubridate)
library(sqldf)
library(dplyr)
library(plyr)
library(ggplot2)

# Reading the Data Set
uber_dataset_original <-
  read.csv('Uber Request Data.csv', stringsAsFactors = F)

# Checking the structure of data frame
str(uber_dataset_original)

# Checking if any na values are present
sum(is.na(uber_dataset_original))

# Checking if any duplicates are present
sum(duplicated(uber_dataset_original))

# Checking the number of columns and Rows in Data Frame
ncol(uber_dataset_original)
nrow(uber_dataset_original)

# Checking the column names of uber_dataset_original data frame
colnames(uber_dataset_original)

# Checking the Summary of uber_dataset_original Data Frame
summary(uber_dataset_original)

# Checking the class of uber_dataset_original Data frame
class(uber_dataset_original)

#  Data Cleaning and Handling of Missing values
#  Assumption
#  To Handle Missing values If Driver id is not available, I have made it to -1 as any driver will not have negative ID
uber_dataset_original$Driver.id <-
  ifelse(is.na(uber_dataset_original$Driver.id) == T,
         -1,
         uber_dataset_original$Driver.id)

# To Handle Missing values If Drop.timestamp is not available, I have made it to 9999/12/31(High End Date) as this date is nearly farthest from current date
uber_dataset_original$Drop.timestamp <-
  ifelse(
    is.na(uber_dataset_original$Drop.timestamp) == T,
    '9999/12/31',
    uber_dataset_original$Drop.timestamp
  )


# To Convert Drop and pick time stamp to default Format
uber_dataset_original$Drop.timestamp <-
  parse_date_time(uber_dataset_original$Drop.timestamp,
                  orders = c('d m y H M S', 'y m d H M', 'd m y H M', 'y m d'))

uber_dataset_original$Request.timestamp <-
  parse_date_time(
    uber_dataset_original$Request.timestamp,
    orders = c('d m y H M S', 'y m d H M', 'd m y H M', 'y m d')
  )

# TO check whether the convert date is of POSIXct Data Type
is(uber_dataset_original$Request.timestamp, "POSIXct")
is(uber_dataset_original$Drop.timestamp, "POSIXct")

# Checking if any na values are present
sum(is.na(uber_dataset_original))

# Checking if any duplicates are present
sum(duplicated(uber_dataset_original))

# Deriving the Required Columns or metrics required for doing EDA
uber_dataset_original$request_day <-
  day(uber_dataset_original$Request.timestamp)
uber_dataset_original$request_hour <-
  hour(uber_dataset_original$Request.timestamp)
uber_dataset_original$request_minute <-
  minute(uber_dataset_original$Request.timestamp)
uber_dataset_original$request_dayname <-
  weekdays(as.Date(uber_dataset_original$Request.timestamp))

#  UDF Data Frsme to Find the Time Slots
data_cluster <- data.frame(hours_time = 0:23)

# Segregating the Time slots
data_cluster <-
  sqldf(
    '
    select
    case when hours_time>=0 and hours_time <4 then "MID Night"
    when hours_time>=4 and hours_time <8 then "Early Morning"
    when hours_time>=8 and hours_time <11 then "Morning"
    when hours_time>=11 and hours_time <13 then "Noon"
    when hours_time>=13 and hours_time <16 then "Afternoon"
    when hours_time>=16 and hours_time <19 then "Evening"
    when hours_time>=19 and hours_time <=23 then "Night" end as Cluster
    ,hours_time
    from data_cluster;'
  )

# Mapping the Derived Slots to uber_dataset_original data frame
uber_dataset_original$slots <-
  mapvalues(
    uber_dataset_original$request_hour,
    from = data_cluster$hours_time ,
    to = data_cluster$Cluster
  )

# Finding the respective Count For each Status
Respective_count <-
  sqldf(
    'select Status,count(*) as individual_count from uber_dataset_original group by Status order by status;'
  )

# Mapping the Dervived Respective Count to Data Frame
uber_dataset_original$Completed <-
  Respective_count[Respective_count$Status == "Trip Completed", ]$individual_count
uber_dataset_original$Cancelled <-
  Respective_count[Respective_count$Status == "Cancelled", ]$individual_count
uber_dataset_original$No_Cars_Available <-
  Respective_count[Respective_count$Status == "No Cars Available", ]$individual_count

# Calculating the Total demands and Total Supply and Total Gap
uber_dataset_original$Demand <-
  uber_dataset_original$Completed + uber_dataset_original$Cancelled + uber_dataset_original$No_Cars_Available
uber_dataset_original$Supply <- uber_dataset_original$Completed
uber_dataset_original$Gap <-
  uber_dataset_original$Cancelled + uber_dataset_original$No_Cars_Available

# Creating Data Frames to find the Demand, Supply and Gap for Various Time Slots
Demand_byslot_df <-
  sqldf("select count(*) as Demand_byslot,slots from uber_dataset_original group by slots")
Gap_bySlot_df <-
  sqldf(
    "select count(*) as Gap_bySlot,slots from uber_dataset_original  where Status in ('Cancelled','No Cars Available') group by slots "
  )
Supply_bySlot_df <-
  sqldf(
    "select count(*) as Supply_bySlot,slots from uber_dataset_original  where Status in ('Trip Completed') group by slots"
  )

# Mapping the above created Demand Slos Number with the uber_dataset_original Data Frame
uber_dataset_original$Demand_byslot <-
  mapvalues(uber_dataset_original$slots,
            from = Demand_byslot_df$slots ,
            to = Demand_byslot_df$Demand_byslot)
uber_dataset_original$Gap_bySlot <-
  mapvalues(uber_dataset_original$slots ,
            from = Gap_bySlot_df$slots ,
            to = Gap_bySlot_df$Gap_bySlot)
uber_dataset_original$Supply_bySlot <-
  mapvalues(uber_dataset_original$slots ,
            from = Supply_bySlot_df$slots ,
            to = Supply_bySlot_df$Supply_bySlot)

# Creating Data Frames to find the Demand, Supply and Gap for Various Time hours
Demand_byhour_df <-
  sqldf(
    "select count(*) as Demand_byhour_Slot,request_hour from uber_dataset_original group by request_hour"
  )
Gap_byhour_df <-
  sqldf(
    "select count(*) as Gap_byhour_Slot,request_hour from uber_dataset_original  where Status in ('Cancelled','No Cars Available') group by request_hour "
  )
Supply_byhour_df <-
  sqldf(
    "select count(*) as Supply_byhour_Slot,request_hour from uber_dataset_original  where Status in ('Trip Completed') group by request_hour"
  )

# Mapping the above created Demand Slos Number with the uber_dataset_original Data Frame
uber_dataset_original$Demand_byhour <-
  mapvalues(
    uber_dataset_original$request_hour,
    from = Demand_byhour_df$request_hour ,
    to = Demand_byhour_df$Demand_byhour
  )
uber_dataset_original$Gap_byhour <-
  mapvalues(
    uber_dataset_original$request_hour ,
    from = Gap_byhour_df$request_hour ,
    to = Gap_byhour_df$Gap_byhour
  )
uber_dataset_original$Supply_byhour <-
  mapvalues(
    uber_dataset_original$request_hour ,
    from = Supply_byhour_df$request_hour ,
    to = Supply_byhour_df$Supply_byhour
  )

# Creating Data Frames to find the Demand, Supply and Gap for Various Time daynames
Demand_bydayname_df <-
  sqldf(
    "select count(*) as Demand_bydayname_Slot,request_dayname from uber_dataset_original group by request_dayname"
  )
Gap_bydayname_df <-
  sqldf(
    "select count(*) as Gap_bydayname_Slot,request_dayname from uber_dataset_original  where Status in ('Cancelled','No Cars Available') group by request_dayname "
  )
Supply_bydayname_df <-
  sqldf(
    "select count(*) as Supply_bydayname_Slot,request_dayname from uber_dataset_original  where Status in ('Trip Completed') group by request_dayname"
  )

# Mapping the above created Demand Slos Number with the uber_dataset_original Data Frame
uber_dataset_original$Demand_bydayname <-
  mapvalues(
    uber_dataset_original$request_dayname,
    from = Demand_bydayname_df$request_dayname ,
    to = Demand_bydayname_df$Demand_bydayname
  )
uber_dataset_original$Gap_bydayname <-
  mapvalues(
    uber_dataset_original$request_dayname ,
    from = Gap_bydayname_df$request_dayname ,
    to = Gap_bydayname_df$Gap_bydayname
  )
uber_dataset_original$Supply_bydayname <-
  mapvalues(
    uber_dataset_original$request_dayname ,
    from = Supply_bydayname_df$request_dayname ,
    to = Supply_bydayname_df$Supply_bydayname
  )

# Removing unwanted objects
rm(Gap_byhour_df,
   Gap_bySlot_df,
   Gap_bydayname_df,
   Respective_count,
   Supply_bydayname_df,
   Supply_byhour_df,
   Supply_bySlot_df,
   data_cluster,
   Demand_byhour_df,
   Demand_byslot_df,
   Demand_bydayname_df)

# Ploting

# Creating UDF Variable which contains themes and can be reused in all plots been drawn
# Theme is been Created for Title and Axis for all Graphs
UDF_Theme_with_legend <-
  theme_bw() +
  theme(
    plot.title = element_text(
      size = 20,
      lineheight = .8,
      face = "bold",
      color = 'Red'
    ),
    legend.background = element_rect(fill = "Orange", size = 0.5),
    axis.title.x = element_text(
      face = "bold",
      colour = 'blue',
      size = 18
    ),
    axis.text.x  = element_text(
      angle = 0,
      face="bold",
      vjust = 0.5,
      size = 12
    ),
    axis.title.y = element_text(
      face = "bold",
      colour = "blue",
      size = 18
    ),
    axis.text.y  = element_text(
      angle = 90,
      face="bold",
      vjust = 0.5,
      size = 12
    )
  )

UDF_Theme_without_legend <-
  theme_bw() +
  theme(
    plot.title = element_text(
      size = 18,
      lineheight = .8,
      face = "bold",
      color = 'Red'
    ),
    axis.title.x = element_text(
      face = "bold",
      colour = 'blue',
      size = 18
    ),
    axis.text.x  = element_text(
      angle = 0,
      face="bold",
      vjust = 0.5,
      size = 12
    ),
    axis.title.y = element_text(
      face = "bold",
      colour = "blue",
      size = 18
    ),
    axis.text.y  = element_text(
      angle = 90,
      face="bold",
      vjust = 0.5,
      size = 12
    ),
    legend.position = "none"
  )

# Create plots to visualise the frequency of requests 
ggplot(uber_dataset_original, aes(x = Status, fill = 'orange')) + geom_bar(width = 0.3) +
  xlab("Status") + ylab(" Frequency of requests ") + geom_text(stat = 'count', aes(label =
                                                                   ..count..),position = position_stack(vjust = 0.5),
                                                               vjust = 0.9,size=5) + 
  ggtitle('Bar Chart Plotting the status Count (Frequency)') +
  UDF_Theme_without_legend

# Create plots to visualise the frequency of requests that get cancelled or show 'no cars available'
ggplot(filter(
  uber_dataset_original,
  uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
) ,
aes(x = Status, fill='orange')) +
  geom_bar(width = 0.5) +
  xlab("Status") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count',
                                             aes(label = ..count..),
                                             position = position_stack(vjust = 0.5),
                                             vjust = 1,
                                             col = 'Black',size=5) + 
  ggtitle('Bar Chart Plotting the status Frequency (Other than Completed)') +
  UDF_Theme_without_legend

# identify the most problematic types of requests (city to airport / airport to city etc.)
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = Pickup.point)
) +
  geom_bar(width = 0.5, fill = 'orange') +
  xlab("Pickup Point") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..),position = position_stack(vjust = 0.5),
                                             vjust = -1,size=5) +
  ggtitle('the frequency of requests that get cancelled or show "no cars available" ') +
  UDF_Theme_without_legend

# Dodge Chart to show most problematic types of requests (city to airport / airport to city)
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = Pickup.point, fill = Status)
) +
  geom_bar(width = 0.5, position = 'dodge') +
  xlab("Pickup Point") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..),position = position_dodge(0.5),
                                             vjust = -0.1) +
  ggtitle(
    "Dodge Chart to show most problematic types of requests (city to airport / airport to city)"
  ) +
  UDF_Theme_with_legend

# the most problematic types of request is city to airport 

# ========================
# identify the most problematic types of time slots (early mornings, late evenings etc.) 
ggplot(filter(
  uber_dataset_original,
  uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
) ,
aes(x = slots ,fill ='orange')) +
  geom_bar(width = 0.5) +
  xlab("Slots") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..),
                                             position = position_stack(vjust = 0.5),vjust = -1) +
  ggtitle(
    "Most problematic types of time slots"
  ) +
  UDF_Theme_without_legend +
  xlim("Early Morning","Morning","Noon","Afternoon","Evening","Night","MID Night")

# Most problematic types of time slots across Status
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = slots, fill = Status)
) +
  geom_bar(width = 0.5) +
  xlab("Slots") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..), 
                                             position = position_stack(vjust = 0.5),
                                             vjust = -0.1) +
  ggtitle(
    "Most problematic types of time slots across Status"
  ) +
  UDF_Theme_with_legend +
  xlim("Early Morning","Morning","Noon","Afternoon","Evening","Night","MID Night")
#  ----------------------------------------------------------------------------
# Most problematic types of request hours 
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in%
      c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = request_hour, fill='orange')
) +
  geom_bar(width = 0.5) +
  xlab("Request Hour") + ylab("Frequency of Request (Count)") +
  geom_text(stat = 'count', aes(label = ..count..),
            position = position_stack(vjust = 0.5),vjust = 0) +
  ggtitle(
    "Most problematic types of request hours "
  ) +
  UDF_Theme_without_legend

#  Most problematic types of request hours (Histogram)
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status
    %in% c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = request_hour)
) +
  geom_histogram(bins = 50) +
  xlab("Request Hour") + ylab("Frequency of Request (Count)") +
  geom_text(stat = 'count', aes(label = ..count..),
            position = position_stack(vjust = 0.5),vjust = 0) +
  ggtitle(
    "Most problematic types of request across hours (Histogram) "
  ) +
    UDF_Theme_without_legend

# Most problematic types of request across hours and status (Histogram) Dodge plot
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in%
      c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = request_hour, fill = Status)
) +
  geom_histogram(bins = 40, position = 'dodge') +
  xlab("Request Hour") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..), vjust = -1) +
  ggtitle("Most problematic types of request across hours and status (Histogram) Dodge Plot") +
  UDF_Theme_with_legend

# Most problematic types of request across hours and status
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = request_hour, fill = Status)
) +
  geom_bar(width = 0.5) +
  ggtitle("Most problematic types of request across hours and status (Histogram)") +
  xlab("Request Hour") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..), vjust = -1) +
  UDF_Theme_with_legend

# Most problematic types of request across hours and status (bar Chart)
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = request_hour, fill = Status)
) +
  geom_bar(width = 0.5, position = 'dodge') +
  xlab("Request Hour") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..),
                                             position = position_dodge(0.9),vjust = 0) +
  ggtitle("Most problematic types of request across hours and status (bar Chart)") +
  UDF_Theme_with_legend

# Most problematic types of request across slots 
ggplot(filter(
  uber_dataset_original,
  uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
) ,
aes(x = slots)) +
  geom_bar(width = 0.5) +
  xlab("Slots") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..), 
                                             position = position_stack(vjust = 0.5),vjust = 0) +
  UDF_Theme_without_legend+
  ggtitle("Most problematic types of request across slots") +
  xlim("Early Morning","Morning","Noon","Afternoon","Evening","Night","MID Night")

# Most problematic types of request across slots and status 
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = slots, fill = Status)
) +
  geom_bar(width = 0.5) +
  xlab("Slots") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..),
                                             position = position_stack(vjust = 0.5),vjust = 0) +
  ggtitle("Most problematic types of request across slots and status") +
  UDF_Theme_with_legend +
  xlim("Early Morning","Morning","Noon","Afternoon","Evening","Night","MID Night")

# Most problematic types of request across Weekday and Status 
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = request_dayname, fill = Status)
) +
  geom_bar(width = 0.5) +
  xlab("Weekday") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..),
                                             position = position_stack(vjust = 0.5),vjust = 0) +
  ggtitle("Most problematic types of request across Weekday and Status") +
  UDF_Theme_with_legend +
xlim("Monday","Tuesday","Wednesday","Thursday","Friday")

# Most problematic types of request across Weekday 
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = request_dayname)
) +
  geom_bar(width = 0.5) +
  xlab("Weekday") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..),
                                             position = position_stack(vjust = 0.5),vjust = 0) +
  ggtitle("Most problematic types of request across Weekday") +
  UDF_Theme_with_legend +
  xlim("Monday","Tuesday","Wednesday","Thursday","Friday")

# Most problematic types of request across Slots and Status
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
  ) ,
  aes(x = slots, fill = Status)
) +
  geom_bar(width = 0.5, position = 'dodge') +
  xlab("Slots") + ylab("Frequency of Request (Count)") + geom_text(stat = 'count', aes(label =
                                                                   ..count..), 
                                             position = position_dodge(0.9),vjust = -0.1,hjust=0.1) +
  ggtitle("Most problematic types of request across Slots and Status") +
  UDF_Theme_with_legend +
  xlim("Early Morning","Morning","Noon","Afternoon","Evening","Night","MID Night")

# Most problematic types of request across Status and Pick up point
ggplot(filter(
  uber_dataset_original,
  uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
),
aes(x = Status)) +
  geom_bar(width = 0.5) +
  facet_wrap("Pickup.point") +
  xlab("Status") +
  ylab("Frequency of Request (Count)") +
  geom_text(stat = 'count', aes(label = ..count..), 
            position = position_stack(vjust = 0.5),vjust = 0) +
  ggtitle("Most problematic types of request across Status and Pick up point")+
  UDF_Theme_without_legend

# =====================================================
# Find the types of requests (city-airport or airport-city) for which the gap is the most severe in the identified time slots
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
    &
      uber_dataset_original$slots == 'Night'
  ),
  aes(x = Status)
) +
  geom_bar(width = 0.5) +
  facet_wrap("Pickup.point") +
  xlab("Status") +
  ylab("Frequency of Request (Count)") +
  ggtitle("The types of requests (city-airport or airport-city) for which the gap is the most severe in the identified time slots") +
  geom_text(stat = 'count', aes(label = ..count..),
            position = position_stack(vjust = 0.5),vjust = 0)  +
  UDF_Theme_without_legend

# the types of requests (city-airport or airport-city) for which the gap is the most severe in the identified time slots
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
    &
      uber_dataset_original$slots == 'Night'
  ),
  aes(x = request_hour)
) +
  geom_bar(width = 0.5) +
  facet_wrap("Pickup.point") +
  xlab("Request Hour") +
  ylab("Frequency of Request (Count)") +
  geom_text(stat = 'count', aes(label = ..count..), 
            position = position_stack(vjust = 0.5),vjust = 0)  +
  UDF_Theme_without_legend +
  ggtitle("the types of requests (city-airport or airport-city) for which the gap is the most severe in the identified time slots ( Night Hours)")

# ------------------------------------

# Problematic request across pick up point and hours
ggplot(
  filter(
    uber_dataset_original,
    uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
  ),
  aes(x = request_hour)
) +
  geom_bar(width = 0.5) +
  facet_wrap("Pickup.point") +
  xlab("Request Hour") +
  ylab("Frequency of Request (Count)") +
  geom_text(stat = 'count', aes(label = ..count..), vjust = -1)  +
  ggtitle("Problematic request across pick up point and hours") +
  UDF_Theme_without_legend

# Problematic request across pick up point and status and slots
ggplot(filter(
  uber_dataset_original,
  uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
),aes(x=Status,fill = slots))+
geom_bar() +
  facet_wrap("Pickup.point") +
ggtitle("Problematic request across pick up point and status and slots") +
  UDF_Theme_with_legend+
  ylab("Frequency of Request (Count)")

# Problematic request across pick up point and status and week day
ggplot(filter(
  uber_dataset_original,
  uber_dataset_original$Status %in% c('Cancelled', 'No Cars Available')
),aes(x=slots,fill = Status))+
  geom_bar(width = 0.5) +
  facet_wrap("Pickup.point") +
  xlab("Slots") +
  ylab("Frequency of Request (Count)") +
  geom_text(stat = 'count', aes(label = ..count..), 
            position = position_stack(vjust = 0.5),vjust = 0)  +
  UDF_Theme_with_legend +
  ggtitle("Problematic request across pick up point and status and week day") +
  xlim("Early Morning","Morning","Noon","Afternoon","Evening","Night","MID Night")

#  Dervive Finish Time
uber_dataset_original$finishtime <-
  ifelse(
    year(uber_dataset_original$Drop.timestamp) != 9999,
    difftime(
      uber_dataset_original$Drop.timestamp ,
      uber_dataset_original$Request.timestamp,
      units = 'mins'
    ),
    NA
  )

# To Find the drivers for whom have complted all the drives
sqldf(
    'select "Driver.id" from ( select "Driver.id",Status, count(*) from uber_dataset_original
where "Driver.id" <> -1 
  group by "Driver.id",Status)a group by "Driver.id" having count(*) =1')

#  UDF to find Demand Supply and Gap
count_Demand_Supply_Gap <- sqldf("select distinct Demand as count ,'Demand' as name  from uber_dataset_original union 
      select distinct Supply , 'Supply' from uber_dataset_original union 
      select distinct  Gap ,'Gap' from uber_dataset_original")

# Pie Chart to Show Demand Supply and Gap
pie(count_Demand_Supply_Gap$count,
    labels = 
      paste(
      count_Demand_Supply_Gap$name,count_Demand_Supply_Gap$count,sep = "-"),main ='Pie Chart to Show Demand Supply and Gap')
# Average FinishTime
mean(uber_dataset_original$finishtime,na.rm = T)


# TO FInd Driver id who have not driven even a single completed ride for a day

uber_dataset_original$requestdate <- as.Date(uber_dataset_original$Request.timestamp)

sqldf(' select distinct "Driver.id"  from uber_dataset_original
      where "Driver.id" <> -1
      group by "Driver.id",requestdate  
      having min("Drop.timestamp")=max("Drop.timestamp") and max("Drop.timestamp")=253402214400 ')


