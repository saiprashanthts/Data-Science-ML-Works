library(lubridate)
library(forecast)
library(graphics)
library(tseries)
library(dplyr)
global_rawdata <- read.csv('Global Superstore.csv',header = TRUE,stringsAsFactors = F)

# Checking the data quality
nrow(global_rawdata) #51290
ncol(global_rawdata) #24
colnames(global_rawdata)
# To check if there i any duplicate values
sum(duplicated(global_rawdata))
# to check if there is any na values present
sum(is.na(global_rawdata)) #41296

# to check if there is blank vaues presnt 
sapply(global_rawdata, function (x) which(x=='') )

# to check number of duplicate values prest in each columns
colSums(is.na(global_rawdata))
# Postal Code has around 41296

colSums(is.na(global_rawdata))['Postal.Code'] /nrow(global_rawdata) 
# Since it has more than 80% of NA so we can drop that column
# Dropping the Postal.Code column
global_rawdata$Postal.Code <- NULL

# now checkin if there is any NA value
sum(is.na(global_rawdata))

# checking the structure of data

str(global_rawdata)

# Converting the string columns to Date
global_rawdata$Order.Date <- as.Date(global_rawdata$Order.Date,format = '%d-%m-%Y')
global_rawdata$Ship.Date <- as.Date(global_rawdata$Ship.Date,format = '%d-%m-%Y')

global_rawdata <- global_rawdata[order(as.Date(global_rawdata$Order.Date, format="%Y/%m/%d")),]

global_rawdata$order_month <- month(global_rawdata$Order.Date)
global_rawdata$order_year <- year(global_rawdata$Order.Date)

# Subsetting the data into subset based on segment and market
splited_data_based_on_seg_cat <-split(global_rawdata,list(global_rawdata$Segment , global_rawdata$Market))

# checking class of new splitted data set
class(splited_data_based_on_seg_cat)

class(splited_data_based_on_seg_cat[[1]])

# checking once the length of splitted data set
length(sapply(splited_data_based_on_seg_cat,levels))
names(sapply(splited_data_based_on_seg_cat,levels))

# to convert list elements into multiple data frame dynamically
list2env(splited_data_based_on_seg_cat ,.GlobalEnv)

# splited_data_based_on_seg_cat[[1]][,c('Order.Date','Sales')]

ts(aggregate(cbind(Sales,Quantity,Profit)~order_month+order_year,splited_data_based_on_seg_cat[[1]],sum))

for (i in names(sapply(splited_data_based_on_seg_cat,levels)))
{
  assign(paste('Derived',i),ts(aggregate(cbind(Sales,Quantity,Profit)~order_month+order_year,splited_data_based_on_seg_cat[[i]],sum)))
}

df=data.frame()
for (i in names(sapply(splited_data_based_on_seg_cat,levels)))
{
  df[i,'sum_of_profits'] <- sum(aggregate(Profit~order_month+order_year,splited_data_based_on_seg_cat[[i]],sum) ['Profit'])
  df[i,'mean_of_profits'] <- lapply((aggregate(Profit~order_month+order_year,splited_data_based_on_seg_cat[[i]],sum) ['Profit']),mean)
  df[i,'sd_of_profits'] <- lapply((aggregate(Profit~order_month+order_year,splited_data_based_on_seg_cat[[i]],sum) ['Profit']),sd)
  df[i,'cv_of_profits'] <- as.numeric(lapply((aggregate(Profit~order_month+order_year,splited_data_based_on_seg_cat[[i]],sum) ['Profit']),mean))/as.numeric(lapply((aggregate(Profit~order_month+order_year,splited_data_based_on_seg_cat[[i]],sum) ['Profit']),sd))
}

df <-df[order(df$cv_of_profits,decreasing = T),]

#extracting top 2 group which has high Cv
df[c(1,2),]



#Market_Segment  Profit_mean Profit_sd   COV
#<fct>                 <dbl>     <dbl> <dbl>
# 1 EU Consumer           3931.     2454. 1.601781
#2 APAC Consumer         4642.     2934. 1.581947




#********************************************************************************************#
#***************************TIMESERIES ANALYSIS*****************************************#
#********************************************************************************************#

#Creating dataset for Consumer.APAC and Consumer.EU

Consumer.APAC.ts <- data.frame(`Derived Consumer.APAC`)
Consumer.EU.ts <- data.frame(`Derived Consumer.EU`)

#creating dataset for sales and qty for consumer APAC and EU

APAC.sales <- data.frame(cbind(1:nrow(Consumer.APAC.ts)), Consumer.APAC.ts[, 3])
colnames(APAC.sales) <- c("Month", "Sales")

APAC.qty <- data.frame(cbind(1:nrow(Consumer.APAC.ts)), Consumer.APAC.ts[, 4])
colnames(APAC.qty) <- c("Month", "Qty")

EU.sales <- data.frame(cbind(1:nrow(Consumer.EU.ts)), Consumer.EU.ts[, 3])
colnames(EU.sales) <- c("Month", "Sales")

EU.qty <- data.frame(cbind(1:nrow(Consumer.EU.ts)), Consumer.EU.ts[, 4])
colnames(EU.qty) <- c("Month", "Qty")

#creating timeseries for sales and qty dataset for APAC and EU

APAC.sales.ts <- ts(APAC.sales$Sales)
APAC.qty.ts <- ts(APAC.qty$Qty)
EU.sales.ts <- ts(EU.sales$Sales)
EU.qty.ts <- ts(EU.qty$Qty)

#creating sales and qty timeseries for EU and APAC

plot(APAC.sales.ts)
plot(APAC.qty.ts)
plot(EU.sales.ts)
plot(EU.qty.ts)

#dividing data in training and testing
APAC.sales.in <- APAC.sales[1:42, ]
APAC.sales.out <- APAC.sales[43:48, ]

APAC.sales.in.ts <- ts(APAC.sales.in$Sales)
APAC.sales.out.ts <- ts(APAC.sales.out$Sales)

##################################################################################################
                              #classical decomposition for APAC sales
##################################################################################################


#Smoothing the series - Moving Average Smoothing
#*******Sale Prediction Start*******************#
w <-1
APAC.sales.smooth <- stats::filter(APAC.sales.in.ts, 
                                filter=rep(1/(2*w+1),(2*w+1)), 
                                method='convolution', sides=2)

#Smoothing left end of the time series

diff <- APAC.sales.smooth[w+2] - APAC.sales.smooth[w+1]
for (i in seq(w,1,-1)) {
  APAC.sales.smooth[i] <- APAC.sales.smooth[i+1] - diff
}

#Smoothing right end of the time series

n <- length(APAC.sales.in.ts)
diff <- APAC.sales.smooth[n-w] - APAC.sales.smooth[n-w-1]
for (i in seq(n-w+1, n)) {
  APAC.sales.smooth[i] <- APAC.sales.smooth[i-1] + diff
}

#Plot the smoothed time series

plot(APAC.sales.in.ts)
lines(APAC.sales.smooth, col="blue", lwd=2)




APAC.sales.time.in <- APAC.sales.in$Month
#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

APAC.sales.smooth.df <- as.data.frame(cbind(APAC.sales.time.in, as.vector(APAC.sales.smooth)))
colnames(APAC.sales.smooth.df) <- c('Month', 'Sales')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function


APAC.sales.lm <- lm(Sales ~ sin(0.5*Month)+cos(0.05*Month) +Month, data=APAC.sales.smooth.df)
APAC.sales.global_pred <- predict(APAC.sales.lm, Month=APAC.sales.time.in)
summary(APAC.sales.global_pred)
lines(APAC.sales.time.in, APAC.sales.global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

APAC.sales.local_pred <- APAC.sales.in.ts-APAC.sales.global_pred
plot(APAC.sales.local_pred, col='red', type = "l")
acf(APAC.sales.local_pred) #ACF is 1 at lag=0 and and other point within the confidence interval
acf(APAC.sales.local_pred, type="partial") #PACF is under confidence interval
APAC.sales.armafit <- auto.arima(APAC.sales.local_pred)

tsdiag(APAC.sales.armafit)
APAC.sales.armafit

#Series: local_pred 
#ARIMA(0,0,0) with zero mean 

#sigma^2 estimated as 112194083:  log likelihood=-448.85
#AIC=899.69   AICc=899.79   BIC=901.43
#as the local pred arima fit is at 0,0,0 this means the local_pred in noise
#to verify doing some test  

plot(APAC.sales.local_pred)
adf.test(APAC.sales.local_pred,alternative = "stationary")
kpss.test(APAC.sales.local_pred)

#Augmented Dickey-Fuller Test

#data:  APAC.sales.local_pred
#Dickey-Fuller = -4.531, Lag order = 3, p-value = 0.01
#alternative hypothesis: stationary

#Warning message:
#  In adf.test(APAC.sales.local_pred, alternative = "stationary") :
#  p-value smaller than printed p-value
#> kpss.test(APAC.sales.local_pred)

#KPSS Test for Level Stationarity

#data:  APAC.sales.local_pred
#KPSS Level = 0.032926, Truncation lag parameter = 1, p-value = 0.1

#as both adf and kpss test shows that the local pred is stationary so using only lm for prediction

APAC.sales.global_pred_out <- predict(APAC.sales.lm,data.frame(Month =APAC.sales.out$Month))
APAC.sales.global_pred_out

#1        2        3        4        5        6 
#46060.58 49697.30 53331.04 56238.91 57878.42 58020.49 

#Now, let's compare our prediction with the actual values, using MAPE

APAC.sales.MAPE <- accuracy(APAC.sales.global_pred_out,APAC.sales.out$Sales)
APAC.sales.MAPE[5]
#21.42166
#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

APAC.sales.class_dec_pred <- c(ts(APAC.sales.global_pred),ts(APAC.sales.global_pred_out))
plot(APAC.sales.ts, col = "black")
lines(APAC.sales.smooth,col="blue")
lines(APAC.sales.class_dec_pred, col = "red")

###Predicting Future 6 Months data######
#Classical Model

forecast.time <- data.frame(Month=49:54)
APAC.sale.forecast <- predict(APAC.sales.lm, forecast.time )
APAC.sale.forecast

#1        2        3        4        5        6 
#56805.67 54709.89 52428.06 50704.09 50148.88 51090.81 

###############
#ARIAM fit for APAC sales
###############

#Building a model on the smoothed time series using Auto Arima
APAC.sale.autoarima <- auto.arima(APAC.sales.in.ts)
APAC.sale.autoarima # auto.arima gives the stationary series at AR=0, differnce =1, MA = 1
tsdiag(APAC.sale.autoarima) 
plot(APAC.sale.autoarima$x, col="black")
lines(fitted(APAC.sale.autoarima), col="red")
lines(APAC.sales.class_dec_pred, col = "blue")

#Again, let's check if the residual series is white noise

APAC.sales.resi.auto <- APAC.sales.in.ts - fitted(APAC.sale.autoarima)

adf.test(APAC.sales.resi.auto,alternative = "stationary")
kpss.test(APAC.sales.resi.auto)

APAC.sale.42.28 <- predict(APAC.sale.autoarima, n.ahead = 6)
#Also, let's evaluate the model using MAPE
APAC.sales.MAPE.auto <- accuracy(APAC.sale.42.28$pred,APAC.sales.out$Sales)
APAC.sales.MAPE.auto[5]
#MAPE = 27.6%%

APAC.sale.forecast.auto <- predict(APAC.sale.autoarima, n.ahead = 12)
APAC.sale.forecast.auto$pred[7:12]

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

APAC.sales.auto.pred <- c(fitted(APAC.sale.autoarima),ts(APAC.sale.forecast.auto$pred))
plot(APAC.sales.ts, col = "black")
lines(APAC.sales.auto.pred, col = "red",lwd=2)
lines(fitted(APAC.sale.autoarima), col = "blue", lwd = 2)

#sales forcast through classical decomposition
#1        2        3        4        5        6 
#56805.67 54709.89 52428.06 50704.09 50148.88 51090.81 



#sales forcast through classical decomposition
#1        2        3        4        5        6 
#44898.7 44898.7 44898.7 44898.7 44898.7 44898.7

###Classical decomposition method works better with less MAPE as compared to auto.arima

#*******Sale Prediction Ends**************************#

#********MOdelling For Quantity***********************#

plot(APAC.qty.ts)

APAC.qty.in <- APAC.qty[1:42, ]
APAC.qty.out <- APAC.qty[43:48, ]

APAC.qty.in.ts <- ts(APAC.qty.in$Qty)
APAC.qty.out.ts <- ts(APAC.qty.out$Qty)
#Smoothing the series - Moving Average Smoothing

w <-1
APAC.qty.smooth <- stats::filter(APAC.qty.in.ts, 
                                filter=rep(1/(2*w+1),(2*w+1)), 
                                method='convolution', sides=2)

#Smoothing left end of the time series

diff <- APAC.qty.smooth[w+2] - APAC.qty.smooth[w+1]
for (i in seq(w,1,-1)) {
  APAC.qty.smooth[i] <- APAC.qty.smooth[i+1] - diff
}

#Smoothing right end of the time series

n <- length(APAC.qty.in.ts)
diff <- APAC.qty.smooth[n-w] - APAC.qty.smooth[n-w-1]
for (i in seq(n-w+1, n)) {
  APAC.qty.smooth[i] <- APAC.qty.smooth[i-1] + diff
}

#Plot the smoothed time series
APAC.qty.time.in <- APAC.qty.in$Month

plot(APAC.qty.in.ts)
lines(APAC.qty.smooth, col="blue", lwd=2)



#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

APAC.qty.smooth.df <- as.data.frame(cbind(APAC.qty.time.in, as.vector(APAC.qty.smooth)))
colnames(APAC.qty.smooth.df) <- c('Month', 'Quantity')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

APAC.qty.lm <- lm(Quantity ~ sin(0.05*Month) * poly(Month,2) + cos(0.5*Month) * poly(Month,2)
            +poly( Month,2), data=APAC.qty.smooth.df)
APAC.qty.global_pred <- predict(APAC.qty.lm, Month=APAC.qty.time.in)
summary(APAC.qty.global_pred)
lines(APAC.qty.time.in, APAC.qty.global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

APAC.qty.local_pred <- APAC.qty.in.ts-APAC.qty.global_pred
plot(APAC.qty.local_pred, col='red', type = "l")
acf(APAC.qty.local_pred)
acf(APAC.qty.local_pred, type="partial")
APAC.qty.armafit <- auto.arima(APAC.qty.local_pred)

tsdiag(APAC.qty.armafit)
APAC.qty.armafit

#Series: local_pred 
#ARIMA(0,0,0) with zero mean 

#sigma^2 estimated as 13610:  log likelihood=-259.49
#AIC=520.97   AICc=521.07   BIC=522.71

#as the auto.arima fit is at 0,0,0 so this means that the local predicted is stationary
#preforming adf and kpss test to verify the same
adf.test(APAC.qty.local_pred,alternative = "stationary")
kpss.test(APAC.qty.local_pred)
#as both adf and kpss test shows that the local predicted value is stationary so using only lm to predict 

APAC.qty.time.out <- APAC.qty.out$Month

APAC.qty.global_pred_out <- predict(APAC.qty.lm,data.frame(Month =APAC.qty.time.out))

#Now, let's compare our prediction with the actual values, using MAPE

MAPE_class_dec <- accuracy(APAC.qty.global_pred_out,APAC.qty.out$Qty)[5]
MAPE_class_dec

##23.94454
#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

APAC.qty.class_dec_pred <- c(ts(APAC.qty.global_pred),ts(APAC.qty.global_pred_out))
plot(APAC.qty.in.ts, col = "black")
lines(APAC.qty.class_dec_pred, col = "red")

###Predicting Future 6 Months data######
#Classical Model

APAC.qty.forecast<-predict(APAC.qty.lm, newdata = forecast.time)
APAC.qty.forecast


#1        2        3        4        5        6 
#1028.968 1141.082 1282.256 1446.739 1625.739 1810.103 

##########################
#ARIMA for APAC QTY
###########################


#Building a model on the smoothed time series using Auto Arima
APAC.qty.autoarima <- auto.arima(APAC.qty.in.ts)
APAC.qty.autoarima
tsdiag(APAC.qty.autoarima)
plot(APAC.qty.autoarima$x, col="black")
lines(fitted(APAC.qty.autoarima), col="red")

#Again, let's check if the residual series is white noise

APAC.qty.resi <- APAC.qty.ts - fitted(APAC.qty.autoarima)

adf.test(APAC.qty.resi,alternative = "stationary")
kpss.test(APAC.qty.resi)
#both adf and kpss test verify that the residual is white noise

#Also, let's evaluate the model using MAPE
APAC.qty.42.48 <- predict(APAC.qty.autoarima, n.ahead = 6)

MAPE_auto_arima <- accuracy(APAC.qty.42.48$pred,APAC.qty.out$Qty)[5]
MAPE_auto_arima
#26.2%

APAC.qty.forecast.auto <- predict(APAC.qty.autoarima, n.ahead = 12)
APAC.qty.forecast.auto$pred[7:12]


#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

APAC.qty.auto_arima_pred <- c(fitted(APAC.qty.autoarima),ts(APAC.qty.forecast.auto$pred[7:12]))
plot(APAC.qty.ts, col = "black")
lines(APAC.qty.auto_arima_pred, col = "red",lwd=2)
lines(APAC.qty.class_dec_pred, col = "blue")


#******************END OF APAC*************************************#

#********************************************************************************************#
#***************************ANLYSIS OF EU CONSUMER*****************************************#
#********************************************************************************************#

EU.sales.in=EU.sales[1:42,]
EU.sales.out=EU.sales[43:48,]

EU.sales.in.ts <- ts(EU.sales.in$Sales)
plot(EU.sales.in.ts)

#***************Sales Pediction Start****************#
#Smoothing the series - Moving Average Smoothing

w <-1
EU.sale.smooth <- stats::filter(EU.sales.in.ts, 
                                filter=rep(1/(2*w+1),(2*w+1)), 
                                method='convolution', sides=2)

#Smoothing left end of the time series

diff <- EU.sale.smooth[w+2] - EU.sale.smooth[w+1]
for (i in seq(w,1,-1)) {
  EU.sale.smooth[i] <- EU.sale.smooth[i+1] - diff
}

#Smoothing right end of the time series

n <- length(EU.sales.in.ts)
diff <- EU.sale.smooth[n-w] - EU.sale.smooth[n-w-1]
for (i in seq(n-w+1, n)) {
  EU.sale.smooth[i] <- EU.sale.smooth[i-1] + diff
}

#Plot the smoothed time series

EU.sales.in.time <- EU.sales.in$Month
lines(EU.sale.smooth, col="blue", lwd=2)



#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

EU.sale.smooth.df <- as.data.frame(cbind(EU.sales.in.time, as.vector(EU.sale.smooth)))
colnames(EU.sale.smooth.df) <- c('Month', 'Sales')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

EU.sales.lm <- lm(Sales ~ sin(0.05*Month) * poly(Month,2) + cos(0.5*Month) * poly(Month,2)
            + poly(Month,2), data=EU.sale.smooth.df)
EU.sales.global_pred <- predict(EU.sales.lm, Month=EU.sales.in.time)
summary(EU.sales.global_pred)
lines(EU.sales.in.time, EU.sales.global_pred, col='red', lwd=2)


#Now, let's look at the locally predictable series
#We will model it as an ARMA series

EU.sale.local_pred <- EU.sales.in.ts-EU.sales.global_pred
plot(EU.sale.local_pred, col='red', type = "l")
acf(EU.sale.local_pred)
acf(EU.sale.local_pred, type="partial")
EU.sales.armafit <- auto.arima(EU.sale.local_pred)

tsdiag(EU.sales.armafit)
EU.sales.armafit

#Series: local_pred 
#ARIMA(0,0,0) with zero mean 

#sigma^2 estimated as 114219919:  log likelihood=-449.22
#AIC=900.44   AICc=900.54   BIC=902.18
#as arima fit is with 0,0,0 this means the local prediction is stationary.
#to verify this performing adf and kpss test on local prediction

adf.test(EU.sale.local_pred,alternative = "stationary")
kpss.test(EU.sale.local_pred)

#Augmented Dickey-Fuller Test

#data:  resi
#Dickey-Fuller = -4.079, Lag order = 3, p-value = 0.01609
#alternative hypothesis: stationary

#> kpss.test(resi)

#KPSS Test for Level Stationarity

#data:  resi
#KPSS Level = 0.029707, Truncation lag parameter = 1, p-value = 0.1

#as both adf and kpss test shows that local prediction is stationary so using only linear model to predict

EU.sales.out.time <- EU.sales.out$Month

EU.sale.global_pred_out <- predict(EU.sales.lm,data.frame(Month =EU.sales.out.time))

#Now, let's compare our prediction with the actual values, using MAPE

EU.sales.MAPE<- accuracy(EU.sale.global_pred_out,EU.sales.out$Sales)[5]
EU.sales.MAPE
#23.87614
#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

EU.sale.class_dec_pred <- c(ts(EU.sales.global_pred),ts(EU.sale.global_pred_out))
plot(EU.sales.ts, col = "black")
lines(EU.sale.class_dec_pred, col = "red")

###Predicting Future 6 Months data######
#Classical Model


EU.sale.forecast<-predict(EU.sales.lm, newdata = forecast.time)
EU.sale.forecast


#1        2        3        4        5        6 
#61248.14 66074.47 71531.63 77309.88 83118.14 88796.39 

#So, that was classical decomposition, now let's do an ARIMA fit



#Building a model on the smoothed time series using Auto Arima
EU.sale.autoarima <- auto.arima(EU.sales.in.ts)
EU.sale.autoarima
tsdiag(EU.sale.autoarima)
plot(EU.sale.autoarima$x, col="black")
lines(fitted(EU.sale.autoarima), col="red")

#Again, let's check if the residual series is white noise

EU.sale.resi <- EU.sales.in.ts - fitted(EU.sale.autoarima)

adf.test(EU.sale.resi,alternative = "stationary")
kpss.test(EU.sale.resi)
#Augmented Dickey-Fuller Test

#data:  resi_auto_arima
#Dickey-Fuller = -4.3522, Lag order = 3, p-value = 0.01
#alternative hypothesis: stationary
#KPSS Test for Level Stationarity

#data:  resi_auto_arima
#KPSS Level = 0.05314, Truncation lag parameter = 1, p-value = 0.1


#Also, let's evaluate the model using MAPE
EU.sale.42.48<- predict(EU.sale.autoarima, n.ahead = 6)

EU.sale.MAPE_auto <- accuracy(EU.sale.42.48$pred,EU.sales.out$Sales)[5]
EU.sale.MAPE_auto
#28.9226

#forecasting for future 6 months sales through auto.arima

EU.sale.forecast.auto <- predict(EU.sale.autoarima, n.ahead = 12)
EU.sale.forecast.auto$pred[7:12]
#1        2       3         4     5           6
#40288.07 39651.62 40168.29 40181.05 39920.18 40065.12


plot(EU.sales.ts, col = "black")
lines(EU.sales.global_pred, col="red")
lines(EU.sale.class_dec_pred, col = "blue",lwd=2)

#*************************END SALES PREDICTION*********#

#********MOdelling For Quantity***********************#

EU.qty.in <- EU.qty[1:42,]
EU.qty.out <- EU.qty[43:48, ]

EU.qty.in.ts <- ts(EU.qty.in$Qty)
plot(EU.qty.in.ts)

#Smoothing the series - Moving Average Smoothing

w <-1
EU.qty.smooth <- stats::filter(EU.qty.in.ts, 
                                filter=rep(1/(2*w+1),(2*w+1)), 
                                method='convolution', sides=2)

#Smoothing left end of the time series

diff <- EU.qty.smooth[w+2] - EU.qty.smooth[w+1]
for (i in seq(w,1,-1)) {
  EU.qty.smooth[i] <- EU.qty.smooth[i+1] - diff
}

#Smoothing right end of the time series

n <- length(EU.qty.in.ts)
diff <- EU.qty.smooth[n-w] - EU.qty.smooth[n-w-1]
for (i in seq(n-w+1, n)) {
  EU.qty.smooth[i] <- EU.qty.smooth[i-1] + diff
}

#Plot the smoothed time series

EU.qty.in.time <- EU.qty.in$Month
lines(EU.qty.smooth, col="blue", lwd=2)



#Building a model on the smoothed time series using classical decomposition
#First, let's convert the time series to a dataframe

EU.qty.smooth.df <- as.data.frame(cbind(EU.qty.in.time, as.vector(EU.qty.smooth)))
colnames(EU.qty.smooth.df) <- c('Month', 'Quantity')

#Now, let's fit a multiplicative model with trend and seasonality to the data
#Seasonality will be modeled using a sinusoid function

EU.qty.lm <- lm(Quantity ~ sin(0.5*Month)*poly(Month,2) + cos(0.5*Month)*poly(Month,2)
            +poly(Month,3)+Month, data=EU.qty.smooth.df)
EU.qty.global_pred <- predict(EU.qty.lm, Month=EU.sales.in.time)
summary(EU.qty.global_pred)
lines(EU.qty.in.time, EU.qty.global_pred, col='red', lwd=2)

#Now, let's look at the locally predictable series
#We will model it as an ARMA series

EU.qty.local_pred <- EU.qty.in.ts-EU.qty.global_pred
plot(EU.qty.local_pred, col='red', type = "l")
acf(EU.qty.local_pred)
acf(EU.qty.local_pred, type="partial")
EU.qty.armafit <- auto.arima(EU.qty.local_pred)

tsdiag(EU.qty.armafit)
EU.qty.armafit

#Series: local_pred 
#ARIMA(2,0,0) with zero mean 

#Coefficients:
#  ar1      ar2
#-0.6295  -0.6116
#s.e.   0.1179   0.1137

#sigma^2 estimated as 7384:  log likelihood=-246.17
#AIC=498.34   AICc=498.97   BIC=503.56

#We'll check if the residual series is white noise

EU.qty.resi <- EU.qty.local_pred-fitted(EU.qty.armafit)

adf.test(EU.qty.resi,alternative = "stationary")
kpss.test(EU.qty.resi)

#Augmented Dickey-Fuller Test

#data:  resi
#Dickey-Fuller = -6.5071, Lag order = 3, p-value = 0.01
#alternative hypothesis: stationary
#KPSS Test for Level Stationarity

#data:  resi
#KPSS Level = 0.028897, Truncation lag parameter = 1, p-value = 0.1

#KPSS Test for Level Stationarity

#data:  resi
#KPSS Level = 0.028897, Truncation lag parameter = 1, p-value = 0.1

EU.qty.out.time <- EU.qty.out$Month

EU.qty.global_pred_out <- predict(EU.qty.lm,data.frame(Month =EU.qty.out.time)) 

EU.qty.local_pred_out <- predict(EU.qty.armafit, n.ahead = 6)

EY.qty.42.48 <- EU.qty.global_pred_out +EU.qty.local_pred_out$pred

#Now, let's compare our prediction with the actual values, using MAPE

EU.qty.MAPE<- accuracy(EY.qty.42.48,EU.qty.out$Qty)[5]
EU.qty.MAPE

##29.7


###Predicting Future 6 Months data######
#Classical Model

EU.qty.forecast_global<-predict(EU.qty.lm, newdata = forecast.time)
EU.qty.forecast_local<-predict(EU.qty.armafit, n.ahead = 12)$pred[7:12]

EU.qty.forecast <- EU.qty.forecast_global+EU.qty.forecast_local
EU.qty.forecast

#1        2        3        4        5        6 
#592.7157 595.1495 629.7121 689.8417 761.6378 838.4546

#Let's also plot the predictions along with original values, to
#get a visual feel of the fit

EU.qty.class_dec_pred <- c(ts(EU.qty.global_pred+fitted(EU.qty.armafit)),ts(EY.qty.42.48))
plot(EU.qty.ts, col = "black")
lines(EU.qty.class_dec_pred, col = "red")

#So, that was classical decomposition, now let's do an ARIMA fit

#Building a model on the smoothed time series using Auto Arima
EU.qty.autoarima <- auto.arima(EU.qty.in.ts)
EU.qty.autoarima
tsdiag(EU.qty.autoarima)
plot(EU.qty.autoarima$x, col="black")
lines(fitted(EU.qty.autoarima), col="red")

#Again, let's check if the residual series is white noise

EU.qty.resi_auto <- EU.qty.in.ts - fitted(EU.qty.autoarima)

adf.test(EU.qty.resi_auto,alternative = "stationary")
kpss.test(EU.qty.resi_auto)

#Augmented Dickey-Fuller Test

#data:  resi_auto_arima
#Dickey-Fuller = -3.5969, Lag order = 3, p-value = 0.04521
#alternative hypothesis: stationary


#KPSS Test for Level Stationarity

#data:  resi_auto_arima
#KPSS Level = 0.047939, Truncation lag parameter = 1, p-value = 0.1

#Also, let's evaluate the model using MAPE
EU.qty.43.48 <- predict(EU.qty.autoarima, n.ahead = 6)

EU.qty.MAPE_auto <- accuracy(EU.qty.43.48$pred,EU.qty.out$Qty)[5]
EU.qty.MAPE_auto
#30.13319

EU.qty.forecast.auto <- predict(EU.qty.autoarima, n.ahead = 12)$pred[7:12]
#466.2458 463.7401 472.9520 467.6464 466.1350 470.3663

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit
EU.qty.auto_arima_pred <- c(fitted(EU.qty.autoarima),ts(EU.qty.forecast.auto))
plot(EU.qty.ts, col = "black")
lines(EU.qty.auto_arima_pred, col = "red",lwd=2)
lines(EU.qty.class_dec_pred, col = "blue", lwd = 2)

#########################################################################

