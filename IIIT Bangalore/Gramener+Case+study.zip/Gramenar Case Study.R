# Calling the required Packages 
library("stringr")
library("lubridate")
library("dplyr")
library("tidyr")
library("lubridate")
library("caret")
library("ggplot2")
library("corrplot")
library("GGally")

# Creating UDF Variable which contains themes and can be reused in all plots been drawn
# Theme is been Created for Title and Axis for all Graphs
UDF_Theme_with_legend <-
  theme_bw() +
  theme(
    plot.title = element_text(
      size = 20,
      lineheight = .8,
      face = "bold",
      color = 'Red'
    ),
    legend.background = element_rect(fill = "Orange", size = 0.5),
    axis.title.x = element_text(
      face = "bold",
      colour = 'blue',
      size = 18
    ),
    axis.text.x  = element_text(
      angle = 0,
      face="bold",
      vjust = 0.5,
      size = 12
    ),
    axis.title.y = element_text(
      face = "bold",
      colour = "blue",
      size = 18
    ),
    axis.text.y  = element_text(
      angle = 90,
      face="bold",
      vjust = 0.5,
      size = 12
    )
  )

UDF_Theme_without_legend <-
  theme_bw() +
  theme(
    plot.title = element_text(
      size = 18,
      lineheight = .8,
      face = "bold",
      color = 'Red'
    ),
    axis.title.x = element_text(
      face = "bold",
      colour = 'blue',
      size = 18
    ),
    axis.text.x  = element_text(
      angle = 0,
      face="bold",
      vjust = 0.5,
      size = 12
    ),
    axis.title.y = element_text(
      face = "bold",
      colour = "blue",
      size = 18
    ),
    axis.text.y  = element_text(
      angle = 90,
      face="bold",
      vjust = 0.5,
      size = 12
    ),
    legend.position = "none"
  )

# Reading the Data Set
loan <- read.csv("loan.csv", stringsAsFactors = F, na.strings = c("NA", "", "NaN", "-", "n/a"))

# Checking the structure of data frame
str(loan)

# Checking if any na values are present
sum(is.na(loan)) # na values are present

# Checking if any duplicates are present
sum(duplicated(loan$id)) # no duplicate entry

# Checking the number of columns and Rows in Data Frame
ncol(loan)
nrow(loan)

# Column names of loan dataset
colnames(loan)

# Summary of loan dataset
summary(loan)

# class of loan dataset
class(loan)

#  Data Cleaning and Handling of Missing values
loan_clean <- loan
#removing columns which contains 100% NA
loan_clean <- loan_clean[, colSums(is.na(loan_clean)) != nrow(loan_clean)]

#data cleaning
#cleaning term by removing "months"
loan_clean$term <- str_remove(loan_clean$term, pattern = "months")

#cleaning interest rate by removing percentage symbol
loan_clean$int_rate <- str_remove(loan_clean$int_rate, pattern = "%")
#converting term to numeric
loan_clean$int_rate <- as.numeric(loan_clean$int_rate)

#cleaning emp_length
unique(loan_clean$emp_length)
#removing year and special character from the emp_length and coverting 10+ years to 10
loan_clean$emp_length <- str_remove_all(loan_clean$emp_length, pattern = c("[A-z, <, +, ]"))


#converting employee title to upper case
loan_clean$emp_title <- str_to_upper(loan_clean$emp_title, locale = "en")
loan_clean$title <- str_to_upper(loan_clean$title, locale = "en")

# Converting all the date columns to default date format
loan_clean$issue_d <- parse_date_time(loan_clean$issue_d, c("by"), tz = "Asia/Calcutta" )
loan_clean$earliest_cr_line <- parse_date_time(loan_clean$earliest_cr_line, c("by"), tz = "Asia/Calcutta" )
loan_clean$last_credit_pull_d <- parse_date_time(loan_clean$last_credit_pull_d, c("by"), tz = "Asia/Calcutta" )
loan_clean$last_pymnt_d <- parse_date_time(loan_clean$last_pymnt_d, c("by"), tz = "Asia/Calcutta" )
loan_clean$next_pymnt_d <- parse_date_time(loan_clean$next_pymnt_d, c("by"), tz = "Asia/Calcutta" )


#converting required columns to factor

to.factor <- c("loan_status","verification_status","purpose", "title", "delinq_2yrs", "inq_last_6mths", "mths_since_last_delinq", "grade", "sub_grade", "term", "emp_length", "home_ownership")
loan_clean[to.factor] <- lapply(loan_clean[to.factor], as.factor)

#removing columns with zero variance with payment plan and application type and initial_list_status
zv <- nearZeroVar(loan_clean, saveMetrics = T)
loan_clean <- loan_clean[, -(which(zv$zeroVar == T))]

loan_clean$revol_util <- str_remove(loan_clean$revol_util, pattern = "%")
loan_clean$revol_util <- as.numeric(loan_clean$revol_util)

namean <- round(colMeans(is.na(loan_clean)), 2)
which(namean >= 0.30)
#removing columns with majority of missing data
loan_clean <- loan_clean[, -(which(namean >= 0.30))]

which(colSums(is.na(loan_clean)) > 0)

# now all the NA are less than 30% so imputing those value with mode/median/mean
loan_clean$emp_title[which(is.na(loan_clean$emp_title))] <- tail(names(sort(table(loan_clean$emp_title))), 1)
loan_clean$emp_length[which(is.na(loan_clean$emp_length))] <- tail(names(sort(table(loan_clean$emp_length))), 1)
loan_clean$title[which(is.na(loan_clean$title))] <- tail(names(sort(table(loan_clean$title))), 1)
summary(loan_clean$revol_util)
loan_clean$revol_util[which(is.na(loan_clean$revol_util))] <- mean(loan_clean$revol_util, na.rm = T) #as mean and median are approx. same
loan_clean$last_pymnt_d[which(is.na(loan_clean$last_pymnt_d))] <- tail(names(sort(table(loan_clean$last_pymnt_d))), 1)
loan_clean$last_credit_pull_d[which(is.na(loan_clean$last_credit_pull_d))] <- tail(names(sort(table(loan_clean$last_credit_pull_d))), 1)
loan_clean$pub_rec_bankruptcies[which(is.na(loan_clean$pub_rec_bankruptcies))] <- tail(names(sort(table(loan_clean$pub_rec_bankruptcies))), 1)

#checking and removing outlier in annual income
ggplot(loan_clean, aes(x="",  y=annual_inc)) + geom_boxplot() + xlab("") + ylab("annual income")

#frequency distribution of annual income befor removing outliers
ggplot(loan_clean, aes(annual_inc)) +geom_freqpoly(binwidth = 10000)

#removing the outliers
iqr <- IQR(loan_clean$annual_inc)
outlier_75 <- quantile(loan_clean$annual_inc, .75) + 1.5*iqr
outlier_25 <- quantile(loan_clean$annual_inc, .25) - 1.5*iqr
outliers <- boxplot.stats(loan_clean$annual_inc)$out # only 4% of data is outliers hence removing that data
loan_clean <- loan_clean[!((loan_clean$annual_inc > outlier_75) | (loan_clean$annual_inc < outlier_25)), ]

#frequency distribution of annual income after removing outliers
ggplot(loan_clean, aes(annual_inc)) +geom_freqpoly(binwidth = 10000)

#derived columns

#grouping loan amount
max(loan_clean$loan_amnt)
min(loan_clean$loan_amnt)
breaks_loan <- c(0, 5000, 10000, 15000, 20000, 25000, 30000, 35000)
labels_loan <- c("<5k", "5-10k", "10-15K", "15-20k", "20-25k", "25-30k", "30-35k")
loan_clean$loan_group<- cut(loan_clean$loan_amnt, breaks = breaks_loan, labels_loan, include.lowest = TRUE)

#grouping funded amount
max(loan_clean$funded_amnt)
min(loan_clean$funded_amnt)
breaks_funded <- c(0, 5000, 10000, 15000, 20000, 25000, 30000, 35000)
labels_funded <- c("<5k", "5-10k", "10-15K", "15-20k", "20-25k", "25--30k", "30-35k")
loan_clean$funded_group<- cut(loan_clean$funded_amnt, breaks = breaks_funded, labels_funded, include.lowest = TRUE)


#grouping annual income
max(loan_clean$annual_inc)
min(loan_clean$annual_inc)
breaks <- c(0, 30000, 60000, 90000, 120000, 150000)
labels <- c("<30k", "30-60k", "60-90K", "90-120k", "120-150k")
loan_clean$income_grp<- cut(loan_clean$annual_inc, breaks = breaks, labels, include.lowest = TRUE)

#deriving column for installment to income ratio
loan_clean <- mutate(loan_clean, installment_to_inc = round(((installment *12)/annual_inc), 2))

#grouping installment to income ratio
max(loan_clean$installment_to_inc)
min(loan_clean$installment_to_inc)
breaks_inst <- c(0, .1, .2, .35)
labels_inst <- c("<10%","10-20%", ">20%")
loan_clean$installment_to_incm_grp<- cut(loan_clean$installment_to_inc, breaks = breaks_inst, labels_inst, include.lowest = TRUE)

#grouping interest rate
max(loan_clean$int_rate)
min(loan_clean$int_rate)
breaks_interest <- c(0, 10, 20, 30)
labels_interest <- c("<10%","10-20%", ">20%")
loan_clean$interest_grp<- cut(loan_clean$int_rate, breaks = breaks_interest, labels_interest, include.lowest = TRUE)

#grouping debt to income ratio (dti)
max(loan_clean$dti)
min(loan_clean$dti)
breaks_dti <- c(0, 10, 20, 30)
labels_dti<- c("<10%","10-20%", ">20%")
loan_clean$dti_grp<- cut(loan_clean$dti, breaks = breaks_dti, labels_dti, include.lowest = TRUE)

loan_clean$issue_yr <- year(loan_clean$issue_d)

# now as we have to analyse the defaulter so taking subset for defaulters

loan_clean_defaulter <- subset(loan_clean, loan_status == "Charged Off")

#univariate analysis
ggplot(loan_clean_defaulter, aes(loan_group)) + geom_bar() + UDF_Theme_without_legend +xlab("loan amount") + ylab("number of defaulter") # maximum defaulter are have taken loan between 5000 to 10000
ggplot(loan_clean_defaulter, aes(funded_group)) + geom_bar() + UDF_Theme_without_legend + xlab("funded amount") + ylab("number of defaulter") # maximum defaulter are have got funding between 5000 to 10000
ggplot(loan_clean_defaulter, aes(income_grp)) + geom_bar() + UDF_Theme_without_legend+ xlab("income") + ylab("number of defaulters")  # people with income between 30k and 60K defaults maximum
ggplot(loan_clean_defaulter, aes(interest_grp)) + geom_bar() + UDF_Theme_without_legend+ xlab("rate of interest") + ylab("number of defaulters")  # loan between interest rate in range of 10-20% defaults maximum
ggplot(loan_clean_defaulter, aes(installment_to_incm_grp)) + geom_bar()+ UDF_Theme_without_legend + xlab("installment to income percentage") + ylab("number of defaulters")  # people whose installment to income ratio is 10% or less defaults maximum

prop.table(table(loan_clean_defaulter$term))
ggplot(loan_clean_defaulter, aes(term)) + geom_bar()+ UDF_Theme_without_legend + xlab("loan tenure") + ylab("number of defaulters") #maximum defaulter have 36month term

round(prop.table(table(loan_clean_defaulter$grade)), 3)
ggplot(loan_clean_defaulter, aes(grade)) + geom_bar()+ UDF_Theme_without_legend+ xlab("loan grade") + ylab("number of defaulters") # most defaulters are in B and C grade category

round(prop.table(table(loan_clean_defaulter$emp_length)), 3)
ggplot(loan_clean_defaulter, aes(emp_length)) + geom_bar()+ UDF_Theme_without_legend+ xlab("employement length") + ylab("number of defaulters") # people who are employed from 10/10+ years default maximum

round(prop.table(table(loan_clean_defaulter$home_ownership)), 3)
ggplot(loan_clean_defaulter, aes(home_ownership)) + geom_bar()+ UDF_Theme_without_legend+ xlab("home ownership") + ylab("number of defaulters")  # people on rented property default maximum

ggplot(loan_clean_defaulter, aes(verification_status)) + geom_bar()+ UDF_Theme_without_legend+ xlab("income verification status") + ylab("number of defaulters") # most defaulters have there income not verified

ggplot(loan_clean_defaulter, aes(addr_state)) + geom_bar() + UDF_Theme_without_legend+ xlab("States") + ylab("number of defaulters")+ theme(axis.text.x = element_text(angle = 90)) # maximum defaulters are in california

ggplot(loan_clean_defaulter, aes(dti_grp)) + geom_bar()+ UDF_Theme_without_legend+ xlab("debt to interest ratio") + ylab("number of defaulters")  # people with debt to income ratio between 10-20% defaults maximum

round(prop.table(table(loan_clean_defaulter$delinq_2yrs)), 3)
ggplot(loan_clean_defaulter, aes(delinq_2yrs)) + geom_bar()+ UDF_Theme_without_legend+ xlab("number of times delinquent") + ylab("number of defaulters")  # people who are paying the installment on time for 2yrs tend to default more

round(prop.table(table(loan_clean_defaulter$inq_last_6mths)), 3)
ggplot(loan_clean_defaulter, aes(inq_last_6mths)) + geom_bar()+ UDF_Theme_without_legend+ xlab("number of enquiry") + ylab("number of defaulters")  # people who has no inqury in 6 months tend to default maximum

ggplot(loan_clean_defaulter, aes(pub_rec_bankruptcies)) + geom_bar()+ UDF_Theme_without_legend + xlab("record of public bankrupcy") + ylab("number of defaulters") # people who do not have any public record of bankrupcy defaults maximum

ggplot(loan_clean_defaulter, aes(year(issue_d))) + geom_bar()+ UDF_Theme_without_legend + xlab("loan issue year") + ylab("number of defaulters") # there is increasing trend in number of defaulters and maximum is in 2011

ggplot(loan_clean_defaulter, aes(factor(month(issue_d)))) + geom_bar() + UDF_Theme_without_legend+ xlab("loan issue month") + ylab("number of defaulters") # maximum defaulter are in the those who got loan in December

ggplot(loan_clean_defaulter, aes(purpose)) + geom_bar() + UDF_Theme_without_legend+ xlab("Purpose") + ylab("number of defaulters")+ theme(axis.text.x = element_text(angle = 90)) # maximum defaulter are those who have taken loan for debt consolidation

ggplot(loan_clean_defaulter, aes(factor(open_acc))) + geom_bar()+ UDF_Theme_without_legend + xlab("number of open account") + ylab("number of defaulters")+ theme(axis.text.x = element_text(angle = 90)) # people with 6-9 open acc defaults maximum

#bivariate

ggplot(loan_clean_defaulter,aes(x=loan_clean_defaulter$income_grp)) + geom_bar(aes(fill = grade), position = "dodge") + 
  facet_grid(~loan_clean_defaulter$loan_group) +
  UDF_Theme_with_legend +
  xlab("Income") + ylab("number of defaulters")  +
  theme(axis.text.x = element_text(angle = 90))
#people in 30k-60k income and 5K-10K loan defaults maximum under grade B

ggplot(loan_clean_defaulter,aes(x=loan_clean_defaulter$income_grp)) + geom_bar(aes(fill = interest_grp), position = "dodge") + 
  facet_grid(~loan_group) +
  UDF_Theme_with_legend +
  xlab("Income") + ylab("number of defaulters")  +
  theme(axis.text.x = element_text(angle = 90))
#in all income group and loan group with the interest rate between 10-20% has maxium defaulter
#out of these defaulters people in income range of 30k-60k and loan amount of 5K-10K and interest rate between 10-20% defaults maximum

ggplot(loan_clean_defaulter,aes(x=income_grp)) + geom_bar(aes(fill =term), position = "dodge") + 
  facet_grid(~loan_group) +
  UDF_Theme_with_legend +
  xlab("Income") + ylab("number of defaulters")  +
  theme(axis.text.x = element_text(angle = 90))
#people in 30k-60k income and 5K-10K loan and 36month of loan defaults the most

ggplot(loan_clean_defaulter,aes(x=income_grp)) + geom_bar(aes(fill =home_ownership), position = "dodge") + 
  facet_grid(~loan_group) +
  UDF_Theme_with_legend +
  xlab("Income") + ylab("number of defaulters")  +
  theme(axis.text.x = element_text(angle = 90))
#people in 30k-60k income and 5K-10K loan with rented property defaults the maximum

ggplot(loan_clean_defaulter,aes(x=income_grp)) + geom_bar(aes(fill =emp_length), position = "dodge") + 
  facet_grid(~loan_group) +
  UDF_Theme_with_legend +
  xlab("Income") + ylab("number of defaulters")  +
  theme(axis.text.x = element_text(angle = 90))
#people in 30k-60k income and 5K-10K loan with employment length of 10/10+ year defaults maximum followed by 1yr

ggplot(loan_clean_defaulter,aes(x=income_grp)) + geom_bar(aes(fill =verification_status), position = "dodge") + 
  facet_grid(~loan_group) +
  UDF_Theme_with_legend +
  xlab("Income") + ylab("number of defaulters")  +
  theme(axis.text.x = element_text(angle = 90))
#people in 30k-60k income and 5K-10K loan with verification status as not verified defaults maximum followed by 1yr

ggplot(loan_clean_defaulter,aes(x=income_grp)) + geom_bar(aes(fill =dti_grp), position = "dodge") + 
  facet_grid(~loan_group) +
  UDF_Theme_with_legend +
  xlab("Income") + ylab("number of defaulters")  +
  theme(axis.text.x = element_text(angle = 90))
#people in 30k-60k income and 5K-10K loan with 10-20% debt to income ratio defaults maximum


# Correlation Graph
loan_clean$rangeforloanstatus <- ifelse(loan_clean$loan_status=="Charged Off",1,0)

corelation_column_names <- c("rangeforloanstatus", "int_rate", "annual_inc",
                             
                             "term"
                             ,"emp_length",
                             "loan_amnt","funded_amnt","funded_amnt_inv",
                             "int_rate","installment",
                             "dti","delinq_2yrs",
                             "inq_last_6mths"
)

corr_df <- loan_clean[,corelation_column_names]
corr_df <- sapply(corr_df,as.numeric)

corrplot(cor(corr_df), method = "number",type = "upper")

# Pair Graphs
ggpairs(loan_clean, columns = c("term"
                                ,"emp_length",
                                "loan_amnt","loan_status"
),
columnLabels = c("term"
                 ,"emp_length",
                 "loan_amnt","loan_status"))

ggpairs(loan_clean, columns = c("loan_amnt"
                                ,"grade",
                                "dti","emp_length"
),
columnLabels = c("loan_amnt"
                 ,"grade",
                 "dti","emp_length"
))


# from above analysis we can infer that
#person is most likely to default if

#annual income is less than 60000
#loan rate is between 10-20%
#working for 10/10+ yrs or 1 yr 
#income is not verified
#Debt to income ratio is between 10-20%
#property is rented

