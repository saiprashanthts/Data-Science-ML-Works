########################################################################
#HR CASE STUDY
#Logistic Regression Assignment
########################################################################

######Installing  Packages#######
# install.packages("dplyr")
# install.packages("tidyverse")
# install.packages("stringr")
# install.packages("MASS")
# install.packages("car")
# install.packages("tidyr")
# install.packages("ggplot2")
# install.packages("lubridate")
# install.packages("sqldf")
# install.packages("anytime")
# install.packages("cowplot")
# install.packages("miscset")
# install.packages("corrplot")
# install.packages("MASS")
# install.packages("car")
# install.packages("caTools")
# install.packages("e1071")
# install.packages("caret")
# install.packages("ROCR")

library(tidyverse)
library(stringr)
library(MASS)
library(car)
library(tidyr)
library(ggplot2)
library(lubridate)
library(anytime)
library(cowplot)
library(miscset)
library(corrplot)
library(car)
library(caTools)
library(e1071)
library(caret)
library(ROCR)
library(dplyr)

#Reading Input files

employee<-read.csv("employee_survey_data.csv",stringsAsFactors = F)
general<-read.csv("general_data.csv",stringsAsFactors = F)
manager<- read.csv("manager_survey_data.csv",stringsAsFactors = F )
in_time <-read.csv("in_time.csv",stringsAsFactors = F,header=TRUE)
out_time <- read.csv("out_time.csv",stringsAsFactors = F)


#Dublicate and NA
str(employee) 
sum(duplicated(employee$EmployeeID)) #4410 Unique Emp ID
sapply(employee, function(x) sum(is.na(x)))  # No NA Emp ID 
#EnvironmentSatisfaction #25 JobSatisfaction #20 WorkLifeBalance #38

str(general)
sum(duplicated(general$EmployeeID)) #4410 Unique Emp ID
sapply(general, function(x) sum(is.na(x)))  # No NA Emp ID 
#NumCompaniesWorked 19 TotalWorkingYears 9

str(manager)
sum(duplicated(manager$EmployeeID)) #4410 Unique Emp ID
sapply(manager, function(x) sum(is.na(x)))  # No NA 

str(in_time)
sum(duplicated(in_time$X)) #4410 Unique Emp ID
sapply(in_time, function(x) sum(is.na(x)))  # No NA Emp ID

str(out_time)
sum(duplicated(out_time$X)) #4410 Unique Emp ID
sapply(out_time, function(x) sum(is.na(x)))  # No NA Emp ID

#Datasets are Unique at Employee ID level

#########################################################
#1.Average Working hours (From In-time and Out-time)
#2.Leaves taken in a year 
#########################################################

in_time1<-Filter(function(in_time)!all(is.na(in_time)), in_time) #Removing variables with all NA
out_time1<-Filter(function(out_time)!all(is.na(out_time)), out_time)#Removing variables with all NA
in_time1[is.na(in_time1)] <- " "
out_time1[is.na(out_time1)] <- " "
in_time1 <- arrange(in_time1, X) #sort
out_time1 <- arrange(out_time1, X)#sort
#Converting to Posixct format
in_time1 <- in_time1 %>%
                       mutate_at(funs(as.POSIXct(., format="%Y-%m-%d %H:%M",origin="1970-01-01")), .vars = vars(1:250))
#Converting to Posixct format
out_time1 <- out_time1 %>%
                       mutate_at(funs(as.POSIXct(., format="%Y-%m-%d %H:%M",origin="1970-01-01")), .vars = vars(1:250))
#Removing 1st column
in_time1<-subset(in_time1, select = -X)
out_time1<-subset(out_time1, select = -X)
#Work Hours 
work_hrs<-data.frame(sapply(1:249, function(i) difftime(time1 = out_time1[,i], time2 = in_time1[,i], units = "hours")))

#Average Work Hours 
Avg_work_hrs <- data.frame(EmployeeID=in_time$X, Avg_hrs = round(rowMeans(work_hrs, na.rm = T),2))
colnames(Avg_work_hrs) [1]  <- "EmployeeID"

######2.Leaves taken by employees (From In-time and Out-time)

leave <- as.data.frame(ifelse(is.na(in_time[,-1]), 1, 0))
leave <- leave[, which(colSums(leave)!=4410)]
Emp_leave_Year <- data.frame(EmployeeID=in_time$X, leave_year = (rowSums(leave)))
colnames(Emp_leave_Year) [1]  <- "EmployeeID"

#########################################################
#Merging all to create a single Master Data 
#########################################################

#Check if all the data have same emplyee Numbers

setdiff(general$EmployeeID, Avg_work_hrs$EmployeeID) #0 (All identical)  
setdiff(general$EmployeeID, employee$EmployeeID) #0 (All identical)  
setdiff(general$EmployeeID, Emp_leave_Year$EmployeeID) #0 (All identical)  
setdiff(general$EmployeeID, employee$EmployeeID) #0 (All identical)  
setdiff(general$EmployeeID, manager$EmployeeID) #0 (All identical)  

master<- merge(general,Avg_work_hrs, by="EmployeeID", all = F)
master<- merge(master,employee, by="EmployeeID", all = F)
master<- merge(master,Emp_leave_Year, by="EmployeeID", all = F)
master<- merge(master,manager, by="EmployeeID", all = F)

#write.csv(master,"master.csv")

##########################################################
#Plotting for Categorical data
##########################################################


bar_theme1<- theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), 
                   legend.position="none")


plot_grid(ggplot(master, aes(x=BusinessTravel,fill=Attrition))+geom_bar(position = "fill")+bar_theme1,
          ggplot(master, aes(x=Department,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          ggplot(master, aes(x=EducationField,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          ggplot(master, aes(x=Gender,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          ggplot(master, aes(x=JobRole,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
           ggplot(master, aes(x=MaritalStatus,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          align = "h") 

plot_grid(ggplot(master, aes(x=StockOptionLevel,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          ggplot(master, aes(x=EnvironmentSatisfaction,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          ggplot(master, aes(x=JobSatisfaction,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          ggplot(master, aes(x=WorkLifeBalance,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          ggplot(master, aes(x=JobInvolvement,fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          ggplot(master, aes(x= factor(PerformanceRating),fill=Attrition))+ geom_bar(position = "fill")+bar_theme1,
          align = "h") 

#From the first plot we can observe that:
# Travel Rarely have high attrition that frequent tarvellers are non travellers
# Research and deelopment has high attrition that other Department
# Life science and Medical education backgrond have high attrition
# Sigle tend to leave more frequently

#From the 2nd plot we can observe that:
# Attrition for performance Rating 3 is more
# Those who have given 3 work life balancce leave more
# High Attrition with job satisfaction 1 and 3

##########################################################
#Plotting for Numerical data
##########################################################
box_theme<- theme(axis.line=element_blank(),axis.title=element_blank(), 
                  axis.ticks=element_blank(), axis.text=element_blank())

box_theme_y<- theme(axis.line.y=element_blank(),axis.title.y=element_blank(), 
                    axis.ticks.y=element_blank(), axis.text.y=element_blank(),
                    legend.position="none")


plot_grid(ggplot(master, aes(x="",y=MonthlyIncome))+ geom_boxplot(width=0.1)+coord_flip(),
ggplot(master, aes(x="",y=DistanceFromHome))+ geom_boxplot(width=0.1)+coord_flip(), 
ggplot(master, aes(x="",y=NumCompaniesWorked))+ geom_boxplot(width=0.1)+coord_flip(),
ggplot(master, aes(x="",y=PercentSalaryHike))+ geom_boxplot(width=0.1)+coord_flip(),
ggplot(master, aes(x="",y=TotalWorkingYears))+ geom_boxplot(width=0.1)+coord_flip(),  
ggplot(master, aes(x="",y=YearsAtCompany))+ geom_boxplot(width=0.1)+coord_flip(), 
ggplot(master, aes(x="",y=YearsSinceLastPromotion))+ geom_boxplot(width=0.1)+coord_flip(),align = "h") 

# Correlation between numeric variables
library(GGally)
ggpairs(master[, c("MonthlyIncome", "DistanceFromHome", "NumCompaniesWorked","PercentSalaryHike","TotalWorkingYears","YearsAtCompany","YearsSinceLastPromotion")])


#To check if the Percentage of outliars is significant
#low - Mean - 3*Stabdard deviation
#Upper - Mean + 3*Stabdard deviation
outliersper <- function(x){
  length(which(x >  mean(x) + 3 * sd(x) | x < mean(x) - 3 * sd(x))  ) / length(x)
}
outliersper(master$MonthlyIncome) # 0% falling in to the criteria
outliersper(master$YearsAtCompany) #1.7%
outliersper(master$TotalWorkingYears) #0%
outliersper(master$YearsSinceLastPromotion) #2.8%

#as percentage of outliers is low its better to impute then removing the data
master[master$YearsAtCompany, "YearsAtCompany"] <- median(master$YearsAtCompany)
master[master$YearsSinceLastPromotion, "YearsAtCompany"] <- median(master$YearsSinceLastPromotion)


#2.5% are NA. Removing NAs

master <- master[!is.na(master$NumCompaniesWorked),]
master <- master[!is.na(master$TotalWorkingYears),]
master <- master[!is.na(master$EnvironmentSatisfaction),]
master <- master[!is.na(master$JobSatisfaction),]
master <- master[!is.na(master$WorkLifeBalance),]
sapply(master, function(x) sum(is.na(x)))

#no NA present in dataset
#using master dataset to create dataset for logistic regression
##########################################################
#Converting Categorical variables to Dummy Varisbles
#Standardizion the Numeric variables
##########################################################

master_all <- subset(master, select = -c(EmployeeID,EmployeeCount,StandardHours,Over18)) # EmployeeCount & StandardHours have all values same

master_all$Attrition <- ifelse(master_all$Attrition =="Yes",1,0)


#All Character
master_char<- master_all[,c(3:4, 6:11, 15, 22:24,26:27 )]

master_fact<- data.frame(sapply(master_char, function(x) factor(x)))
str(master_fact)



dummy_char<- data.frame(sapply(master_fact, 
                            function(x) data.frame(model.matrix(~x-1,data =master_fact))[,-1]))



#All Numeric
master_nums<- master_all[,-c(3:4, 6:11, 15, 22:24,26:27 )]
master_nums_scale<-master_nums[,c(1,3:13)]
master_nums_scale <- data.frame(sapply(master_nums_scale, function(x) scale(x)))
master_nums       <-  data.frame(Attrition = master_nums$Attrition)


master_final<-cbind(master_nums,master_nums_scale,dummy_char)

###############################################################
#Correlation
###############################################################

corr <- cor(master_final)
################################################################
# splitting the data between train and test
################################################################
set.seed(100)

indices = sample.split(master_final$Attrition, SplitRatio = 0.7)

train = master_final[indices,]

test = master_final[!(indices),]
################################################################
# Logistic Regresstions
################################################################

model_1 = glm(Attrition ~ ., data = train, family = "binomial")
summary(model_1) #AIC 2119.6......nullDev 2661.4...resDev 2005.7

model_2<- stepAIC(model_1, direction="both")

summary(model_2)


sort((vif(model_2)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#Removing  BusinessTravel.xTravel_Rarely  as VIF and p value is high

model_3<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
               TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
               Avg_hrs + BusinessTravel.xTravel_Frequently  + 
               Education.x5 + EducationField.xLife.Sciences + EducationField.xMarketing + 
               EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
               JobLevel.x2 + JobLevel.x5 + JobRole.xHuman.Resources + JobRole.xManager + 
               JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
               JobRole.xSales.Executive + MaritalStatus.xMarried + MaritalStatus.xSingle + 
               StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
               EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
               JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
               WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
             data = train)

summary(model_3)

sort((vif(model_3)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#Removing MaritalStatus.xMarried +  as VIF and p value is high

model_4<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
               TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
               Avg_hrs + BusinessTravel.xTravel_Frequently + Education.x5 + 
               EducationField.xLife.Sciences + EducationField.xMarketing + 
               EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
               JobLevel.x2 + JobLevel.x5 + JobRole.xHuman.Resources + JobRole.xManager + 
               JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
               JobRole.xSales.Executive  + MaritalStatus.xSingle + 
               StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
               EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
               JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
               WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
             data = train)
summary(model_4)

sort((vif(model_4)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#Removing  JobLevel.x5   as least significant

model_5<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
               TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
               Avg_hrs + BusinessTravel.xTravel_Frequently + Education.x5 + 
               EducationField.xLife.Sciences + EducationField.xMarketing + 
               EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
               JobLevel.x2 + JobRole.xHuman.Resources + JobRole.xManager + 
               JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
               JobRole.xSales.Executive  + MaritalStatus.xSingle + 
               StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
               EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
               JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
               WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
             data = train)
summary(model_5)

sort((vif(model_5)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#Removing  JobRole.xHuman.Resources   as least significant

model_6<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
               TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
               Avg_hrs + BusinessTravel.xTravel_Frequently + Education.x5 + 
               EducationField.xLife.Sciences + EducationField.xMarketing + 
               EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
               JobLevel.x2  + JobRole.xManager + 
               JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
               JobRole.xSales.Executive  + MaritalStatus.xSingle + 
               StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
               EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
               JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
               WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
             data = train)
summary(model_6)

sort((vif(model_6)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#Removing   Education.x5   as least significant

model_7<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
               TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
               Avg_hrs + BusinessTravel.xTravel_Frequently + 
               EducationField.xLife.Sciences + EducationField.xMarketing + 
               EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
               JobLevel.x2  + JobRole.xManager + 
               JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
               JobRole.xSales.Executive  + MaritalStatus.xSingle + 
               StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
               EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
               JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
               WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
             data = train)
summary(model_7)

sort((vif(model_7)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable


#Removing   JobRole.xManager   as least significant

model_8<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
               TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
               Avg_hrs + BusinessTravel.xTravel_Frequently + 
               EducationField.xLife.Sciences + EducationField.xMarketing + 
               EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
               JobLevel.x2   + 
               JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
               JobRole.xSales.Executive  + MaritalStatus.xSingle + 
               StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
               EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
               JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
               WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
             data = train)
summary(model_8)

sort((vif(model_8)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable


#Removing   JobLevel.x2     as least significant

model_9<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
               TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
               Avg_hrs + BusinessTravel.xTravel_Frequently + 
               EducationField.xLife.Sciences + EducationField.xMarketing + 
               EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
               JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
               JobRole.xSales.Executive  + MaritalStatus.xSingle + 
               StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
               EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
               JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
               WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
             data = train)
summary(model_9)

sort((vif(model_9)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable


#Removing    JobInvolvement.x3     as least significant

model_10<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
               TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
               Avg_hrs + BusinessTravel.xTravel_Frequently + 
               EducationField.xLife.Sciences + EducationField.xMarketing + 
               EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
               JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
               JobRole.xSales.Executive  + MaritalStatus.xSingle + 
               StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
               EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
               JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
               WorkLifeBalance.x4, family = "binomial", 
             data = train)
summary(model_10)

sort((vif(model_10)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable


#Removing    StockOptionLevel.x1     as least significant

model_11<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                EducationField.xLife.Sciences + EducationField.xMarketing + 
                EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                JobRole.xSales.Executive  + MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4, family = "binomial", 
              data = train)
summary(model_11)

sort((vif(model_11)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#Removing    JobRole.xSales.Executive     as least significant

model_12<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                EducationField.xLife.Sciences + EducationField.xMarketing + 
                EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4, family = "binomial", 
              data = train)
summary(model_12)

sort((vif(model_12)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable


#Removing    JobRole.xResearch.Director     as least significant

model_13<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                EducationField.xLife.Sciences + EducationField.xMarketing + 
                EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4, family = "binomial", 
              data = train)
summary(model_13)

sort((vif(model_13)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#as all the variables are significant but vif of variables is still greater than 2, so removing the variable which has highest vif

#Removing    EducationField.xLife.Sciences     as it has highest vif

model_14<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                EducationField.xMarketing + 
                EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4, family = "binomial", 
              data = train)
summary(model_14)

sort((vif(model_14)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#Removing    EducationField.xMarketing     as it is least significant

model_15<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4, family = "binomial", 
              data = train)
summary(model_15)

sort((vif(model_15)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#Removing    EducationField.xMedical     as it is least significant

model_16<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                EducationField.xOther + EducationField.xTechnical.Degree + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4, family = "binomial", 
              data = train)
summary(model_16)

sort((vif(model_16)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#Removing    EducationField.xOther     as it is least significant

model_17<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                EducationField.xTechnical.Degree + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4, family = "binomial", 
              data = train)
summary(model_17)

sort((vif(model_17)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#Removing    EducationField.xTechnical.Degree     as it is least significant

model_18<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                WorkLifeBalance.x4, family = "binomial", 
              data = train)
summary(model_18)

sort((vif(model_18)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#removing WorkLifeBalance.x3 as it has highest vif

model_19<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2 + 
                WorkLifeBalance.x4, family = "binomial", 
              data = train)
summary(model_19)

sort((vif(model_19)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#removing worklifebalanc.4 as it is least significant

model_20<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 + WorkLifeBalance.x2, family = "binomial", 
              data = train)
summary(model_20)

sort((vif(model_20)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#removing WorkLifeBalance.x2 as it is least significant

model_21<-glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 , family = "binomial", 
              data = train)
summary(model_21)

sort((vif(model_21)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#removing TotalWorkingYears as it has vif greater than 2

model_22<-glm(formula = Attrition ~ Age + NumCompaniesWorked  + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                JobSatisfaction.x4 , family = "binomial", 
              data = train)
summary(model_22)

sort((vif(model_22)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#removing JobSatisfaction.x2 as it is least significant

model_23<-glm(formula = Attrition ~ Age + NumCompaniesWorked  + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4  + JobSatisfaction.x3 + 
                JobSatisfaction.x4 , family = "binomial", 
              data = train)
summary(model_23)

sort((vif(model_23)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable


#removing JobSatisfaction.x3 as it is least significant

model_24<-glm(formula = Attrition ~ Age + NumCompaniesWorked  + 
                TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                Avg_hrs + BusinessTravel.xTravel_Frequently + 
                JobRole.xManufacturing.Director + 
                MaritalStatus.xSingle + 
                EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                EnvironmentSatisfaction.x4   + 
                JobSatisfaction.x4 , family = "binomial", 
              data = train)
summary(model_24)

sort((vif(model_24)), decreasing = TRUE) #sorting and checking for the highest VIF valued variable

#now all the variables are highly significant with vif less than 2.so taking model_24 as final model
#AIC = 2203.6
#Final Model

final_model<- model_24
# Final Variables
#1. Years Since Last Promotion
#2. Environment Satisfaction
#3. Years With Curr Manager
#4. Num Companies Worked
#5. Age
#6. Avg hrs (avg working hours)
#7. Marital Status
#8. Job Role
#9. Training times last year
#10. Busniness Travel
#11. Job satisfaction
################################################################
# MOdel Evaluation
################################################################

#predicted probabilities of Attrition for test data

test_pred = predict(final_model, type = "response", 
                    newdata = test[,-1])


# Let's see the summary 

summary(test_pred)

test$prob <- test_pred
View(test)
# Let's use the probability cutoff of 50%.

test_pred_Attr <- factor(ifelse(test_pred >= 0.50, "Yes", "No"))
test_actual_Attr <- factor(ifelse(test$Attrition==1,"Yes","No"))
test_conf1 <- confusionMatrix(test_pred_Attr, test_actual_Attr, positive = "Yes")
test_conf1

table(test_actual_Attr,test_pred_Attr)

#as the sensitivity is low as compared to accuracy of the model so determing optimal cutoff of the probability so that accuracy, sensitivity and specificity are approx. equal
#################################################################
# cutoff value. 
#################################################################
perform_fn <- function(cutoff) 
{
  predicted_attr <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_attr, test_actual_Attr, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

summary(test_pred)

s = seq(.01,.80,length=100)

OUT = matrix(0,100,3)


for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 


plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.01)]


# Let's choose a cutoff value of 0.18 for final model

test_cutoff_Attr <- factor(ifelse(test_pred >=0.18, "Yes", "No"))

conf_final <- confusionMatrix(test_cutoff_Attr, test_actual_Attr, positive = "Yes")

acc <- conf_final$overall[1] #76.7%

sens <- conf_final$byClass[1] #75.6

spec <- conf_final$byClass[2] #76.9

acc

sens

spec

View(test)
##################################################################################################
### KS -statistic - Test Data ######

test_cutoff_Attr <- ifelse(test_cutoff_Attr=="Yes",1,0)
test_actual_Attr <- ifelse(test_actual_Attr=="Yes",1,0)


library(ROCR)
#on testing  data
pred_object_test<- prediction(test_cutoff_Attr, test_actual_Attr)

performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])

max(ks_table_test)
#ks value is .524

auc = performance(pred_object_test, measure = "auc")
auc = auc@y.values[[1]]

#area under curve is .76
####################################################################
# Lift & Gain Chart 

# plotting the lift chart

# Loading dplyr package 
require(dplyr)
library(dplyr)

lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

attrition_decile = lift(test_actual_Attr, test_pred, groups = 10)

#gain chart
ggplot(attrition_decile, aes(bucket, Gain)) +geom_line()

#visualizing the varaibles got from final model

# Creating UDF Variable which contains themes and can be reused in all plots been drawn
# Theme is been Created for Title and Axis for all Graphs
UDF_Theme_with_legend <-
  theme_bw() +
  theme(
    plot.title = element_text(
      size = 20,
      lineheight = .8,
      face = "bold",
      color = 'Red'
    ),
    legend.background = element_rect(fill = "Orange", size = 0.5),
    axis.title.x = element_text(
      face = "bold",
      colour = 'blue',
      size = 18
    ),
    axis.text.x  = element_text(
      angle = 0,
      face="bold",
      vjust = 0.5,
      size = 12
    ),
    axis.title.y = element_text(
      face = "bold",
      colour = "blue",
      size = 18
    ),
    axis.text.y  = element_text(
      angle = 90,
      face="bold",
      vjust = 0.5,
      size = 12
    )
  )

UDF_Theme_without_legend <-
  theme_bw() +
  theme(
    plot.title = element_text(
      size = 18,
      lineheight = .8,
      face = "bold",
      color = 'Red'
    ),
    axis.title.x = element_text(
      face = "bold",
      colour = 'blue',
      size = 18
    ),
    axis.text.x  = element_text(
      angle = 0,
      face="bold",
      vjust = 0.5,
      size = 12
    ),
    axis.title.y = element_text(
      face = "bold",
      colour = "blue",
      size = 18
    ),
    axis.text.y  = element_text(
      angle = 90,
      face="bold",
      vjust = 0.5,
      size = 12
    ),
    legend.position = "none"
  )



ggplot(master, aes(JobRole, fill = Attrition)) + geom_bar(position = "fill") + bar_theme1
ggplot(master, aes(BusinessTravel, fill = Attrition)) + geom_bar(position = "fill")
ggplot(master, aes(factor(JobSatisfaction), fill = Attrition)) + geom_bar(position = "fill") +xlab("Job Satisfaction")
ggplot(master, aes(factor(TrainingTimesLastYear), fill = Attrition)) + geom_bar(position = "fill") +xlab("Training Times Last Year")
ggplot(master, aes(master$EnvironmentSatisfaction, fill = Attrition)) + geom_bar(position = "fill") +xlab("Environment Satisfaction")
ggplot(master, aes(factor(YearsSinceLastPromotion), fill = Attrition )) + geom_bar(position = "fill") +xlab("Years Since Last Promotion")
ggplot(master, aes(factor(YearsWithCurrManager), fill = Attrition )) + geom_bar(position = "fill") +xlab("Years With Curr Manager")
ggplot(master, aes(factor(NumCompaniesWorked), fill = Attrition )) + geom_bar(position = "fill") +xlab("Num Companies Worked")


#as age cannot be analysed directly so breaking age in bins
max(master$Age)
min(master$Age)
breaks_age <- c(min(master$Age), 26, 34, 42, 50, max(master$Age))
labels_age <- c("18-26Y", "27-34Y", "35-42Y", "43-50Y", "51-60Y")
master$Age_group<- cut(master$Age, breaks = breaks_age, labels_age, include.lowest = TRUE)
ggplot(master, aes(factor(Age_group), fill = Attrition )) + geom_bar(position = "fill") +xlab("Age"
                                                                                              )
boxplot(Avg_hrs ~ Attrition, master)

ggplot(master, aes(MaritalStatus, fill = Attrition )) + geom_bar(position = "fill")

#####################################################################################################################
